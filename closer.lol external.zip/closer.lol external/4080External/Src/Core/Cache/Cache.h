#pragma once
// language: C++, file: closer.lol/Src/Core/Cache/Cache.h — universal R6/R15
#include "../../Game/SDK/SDK.h"
#include "../Globals/Globals.h"
#include <vector>
#include <string>
#include <algorithm>
#include <cstdio>

namespace PlayerCache {
    struct CachedPlayer {
        uintptr_t playerAddr = 0, characterAddr = 0, humanoidAddr = 0, rootPartAddr = 0, headAddr = 0, teamAddr = 0;
        std::string name, displayName, tool;
        RBX::Vec3 position{}, velocity{};
        float health = 0, maxHealth = 100, distance = 0;
        bool knocked = false, isValid = false;
        // backtrack ring: position records for lag compensation
        static constexpr int HIST = 16;
        RBX::Vec3 hist[HIST]{};
        int histHead = 0, histCount = 0;
        void PushHist(const RBX::Vec3& p) { hist[histHead] = p; histHead = (histHead + 1) % HIST; if (histCount < HIST) histCount++; }
        RBX::Vec3 Backtrack(float ms) const {
            if (histCount == 0) return position;
            int steps = (int)(ms / 16.7f); // ~1 record per frame at 60fps
            if (steps >= histCount) steps = histCount - 1;
            int idx = (histHead - 1 - steps + HIST * 2) % HIST;
            return hist[idx];
        }
    };
    inline std::vector<CachedPlayer> players;
    inline RBX::Vec3 localPlayerPos{};
    inline int diagScanned = 0, diagNoChar = 0, diagNoHum = 0, diagDead = 0;
    inline int rescanTick = 0;
    inline std::string diagFirstFail = "";
    inline int diagLoggedTick = 0;

    // Re-resolve core pointers periodically: survives join/teleport/client hiccups.
    inline void RescanCore() {
        if (++rescanTick % 300 != 0) return;
        auto dm = Globals::dataModel;
        auto ws = dm.FindChildAny("Workspace");
        if (ws) Globals::workspace = ws;
        auto pl = dm.FindChildAny("Players");
        if (pl) Globals::players = pl;
        if (Globals::workspace) {
            auto cam = Globals::workspace.FindChildAny("Camera");
            if (cam) Globals::camera = cam;
        }
        if (Globals::players)
            Globals::localPlayer = RBX::RbxInstance(Coms->ReadMemory<uintptr_t>(Globals::players.Addr + RBX::Live::oLocalPlayer));
    }

    // Fallback: find character model under Workspace by player name.
    inline RBX::RbxInstance FindCharInWorkspace(const std::string& name) {
        if (!Globals::workspace || name.empty()) return RBX::RbxInstance(0);
        auto ch = Globals::workspace.FindChild(name);
        if (ch && ch.FindChildByClass("Humanoid")) return ch;
        return RBX::RbxInstance(0);
    }

    inline void UpdatePlayers() {
        RescanCore();
        diagScanned = diagNoChar = diagNoHum = diagDead = 0;
        if (++diagLoggedTick % 600 == 0) diagFirstFail.clear();
        auto list = Globals::players.GetChildList();
        auto localChar = Globals::localPlayer.GetModelRef();
        if (!localChar) return;
        auto localRoot = localChar.FindChild("HumanoidRootPart");
        if (!localRoot) localRoot = localChar.FindChild("Torso");
        if (!localRoot) return;
        localPlayerPos = localRoot.GetPos();
        // local health drives dead-pause (aim/silent sleep while you are dead)
        {
            auto lh = localChar.FindChild("Humanoid");
            if (!lh) lh = localChar.FindChildByClass("Humanoid");
            if (lh) {
                float h = RBX::RbxInstance(0).ReadHealth(lh.Addr);
                Globals::localHealth = (h < 0) ? 100.0f : h;
            }
        }
        Globals::localTeam = Coms->ReadMemory<uintptr_t>(Globals::localPlayer.Addr + offsets::Team);

        for (auto& c : players) c.isValid = false;
        for (auto& plr : list) {
            if (plr.Addr == Globals::localPlayer.Addr) continue;
            diagScanned++;
            CachedPlayer* e = nullptr;
            for (auto& c : players) if (c.playerAddr == plr.Addr) { e = &c; break; }
            if (!e) { CachedPlayer np; np.playerAddr = plr.Addr; players.push_back(np); e = &players.back(); }
            auto ch = plr.GetModelRef();
            if (!ch) {
                // fallback: character may be child model — search children for Humanoid
                for (auto& c : plr.GetChildList()) {
                    if (c.FindChildByClass("Humanoid")) { ch = c; break; }
                }
                // fallback 2: Workspace model matching player name
                if (!ch && !e->name.empty()) ch = FindCharInWorkspace(e->name);
                else if (!ch) {
                    std::string pn = plr.GetName();
                    if (!pn.empty()) { e->name = pn; ch = FindCharInWorkspace(pn); }
                }
                if (!ch) { diagNoChar++; continue; }
            }
            e->characterAddr = ch.Addr;
            // Humanoid by NAME first (names decode reliably; class reads flake on some objects)
            auto hum = ch.FindChild("Humanoid");
            if (!hum) hum = ch.FindChildByClass("Humanoid");
            if (!hum) {
                diagNoHum++;
                // deep debug: capture WHY once per rescan window
                if (diagFirstFail.empty()) {
                    auto kids = ch.GetChildList();
                    char buf[256];
                    snprintf(buf, sizeof(buf), "plr=0x%llX ch=0x%llX kids=%zu first=[%s]<%s>",
                        (unsigned long long)plr.Addr, (unsigned long long)ch.Addr, kids.size(),
                        kids.empty() ? "none" : kids[0].GetName().c_str(),
                        kids.empty() ? "none" : kids[0].GetClass().c_str());
                    diagFirstFail = buf;
                }
                continue;
            }
            e->humanoidAddr = hum.Addr;
            auto root = ch.FindChild("HumanoidRootPart");
            if (!root) root = ch.FindChild("Torso");
            if (!root) root = ch.FindChild("LowerTorso");
            if (!root) { diagNoChar++; continue; }
            e->rootPartAddr = root.Addr;
            e->headAddr = ch.FindChild("Head").Addr;
            e->position = root.GetPos();
            e->velocity = RBX::RbxInstance(0).ReadVelocity(root.Addr);
            e->health = RBX::RbxInstance(0).ReadHealth(hum.Addr);
            e->maxHealth = RBX::RbxInstance(0).ReadMaxHealth(hum.Addr);
            if (e->health < 0) e->health = e->maxHealth; // unreadable != dead: show, don't hide
            if (e->health == 0) { diagDead++; continue; }
            e->knocked = RBX::RbxInstance(0).IsKnocked(hum.Addr);
            e->teamAddr = Coms->ReadMemory<uintptr_t>(plr.Addr + offsets::Team);
            e->distance = root.DistTo(localPlayerPos);
            e->PushHist(e->position);
            if (e->name.empty()) e->name = plr.GetName();
            if (e->name.empty()) e->name = "Player_" + std::to_string(e->playerAddr & 0xFFFF);
            e->displayName = RBX::RbxInstance(0).ReadDisplayName(plr.Addr);
            e->tool = RBX::RbxInstance(0).ReadEquippedTool(ch);
            e->isValid = true;
        }
        players.erase(std::remove_if(players.begin(), players.end(),
            [](const CachedPlayer& p){ return !p.isValid; }), players.end());
    }
}
