#pragma once
// language: C++, file: closer.lol/Src/Core/Features/Aimbot/Aimbot.h — universal aim
#include "../../../Game/W2S/W2S.h"
#include "../../Cache/Cache.h"
#include "../../Vars/Vars.h"
#include <windows.h>
#include <cmath>
#include <cfloat>

namespace Aimbot {
    inline uintptr_t locked = 0;
    inline bool toggleState = false;
    inline int lastKeyBit = 0;
    inline bool forceActive = false; // selftest: bypass key gate
    inline DWORD lockStart = 0;
    inline DWORD unlockUntil = 0;
    inline float lockedLastHealth = 0;

    inline void MoveMouse(float x, float y) {
        INPUT in{}; in.type = INPUT_MOUSE; in.mi.dwFlags = MOUSEEVENTF_MOVE;
        in.mi.dx = (LONG)x; in.mi.dy = (LONG)y;
        SendInput(1, &in, sizeof(in));
    }
    inline float Dist2D(RBX::Vec2 a, RBX::Vec2 b) {
        float dx=a.X-b.X, dy=a.Y-b.Y; return sqrtf(dx*dx+dy*dy);
    }
    inline bool KeyHeld(int k) {
        if (k==1) return GetAsyncKeyState(VK_LBUTTON)&0x8000;
        if (k==2) return GetAsyncKeyState(VK_RBUTTON)&0x8000;
        if (k==4) return GetAsyncKeyState(VK_MBUTTON)&0x8000;
        if (k==5) return GetAsyncKeyState(VK_XBUTTON1)&0x8000;
        if (k==6) return GetAsyncKeyState(VK_XBUTTON2)&0x8000;
        return k>0 && (GetAsyncKeyState(k)&0x8000);
    }
    // Hold vs toggle gating.
    inline bool AimActive() {
        bool held = KeyHeld(Vars::Aimbot::aimbotKey);
        if (Vars::Aimbot::toggle) {
            int bit = held ? 1 : 0;
            if (bit && !lastKeyBit) toggleState = !toggleState;
            lastKeyBit = bit;
            return toggleState;
        }
        if (!held) { toggleState = false; lastKeyBit = 0; }
        return held;
    }

    inline bool PassesChecks(const PlayerCache::CachedPlayer& p) {
        if (!p.isValid) return false;
        if (Vars::Aimbot::teamCheck && p.teamAddr && p.teamAddr == Globals::localTeam) return false;
        if (Vars::Aimbot::healthCheck && p.health <= 0) return false;
        if (Vars::Aimbot::knockCheck && p.knocked) return false;
        if (Vars::Aimbot::distance > 0 && p.distance > Vars::Aimbot::distance) return false;
        return true;
    }

    // Velocity prediction: lead the target. ~0.12s good for DaHood-speed games.
    inline RBX::Vec3 Predict(const PlayerCache::CachedPlayer& p, const RBX::Vec3& base) {
        float t = Vars::Aimbot::prediction;
        if (t <= 0) return base;
        return { base.X + p.velocity.X * t, base.Y + p.velocity.Y * t, base.Z + p.velocity.Z * t };
    }

    inline RBX::Vec3 TargetPos(const PlayerCache::CachedPlayer& p) {
        RBX::Vec3 anchor = p.position;
        if (Vars::HvH::backtrack) anchor = p.Backtrack(Vars::HvH::backtrackMs);
        RBX::RbxInstance ch(p.characterAddr);
        int idx = Vars::Aimbot::hitPart;
        RBX::Vec3 base;
        // Closest is resolved per-frame by the caller via TargetPosClosest; default here is head.
        auto part = ch.ResolveHitPart(ch, idx > 5 ? 0 : idx, p.rootPartAddr);
        base = part ? part.GetPos() : anchor;
        if (Vars::HvH::backtrack) {
            // shift part offset onto backtracked anchor
            base.X += anchor.X - p.position.X; base.Y += anchor.Y - p.position.Y; base.Z += anchor.Z - p.position.Z;
        }
        // stale-part guard: head 50m+ from root = dead model, fall back to root
        {
            float dx = base.X - p.position.X, dy = base.Y - p.position.Y, dz = base.Z - p.position.Z;
            if (dx*dx + dy*dy + dz*dz > 2500.0f) base = anchor;
        }
        return Predict(p, base);
    }

    inline void Unlock() { locked = 0; Globals::aimTargetAddr = 0; lockStart = 0; }

    // True closest-part: project head/torso/root, return the world pos nearest the cursor.
    inline RBX::Vec3 TargetPosClosest(const PlayerCache::CachedPlayer& p, const RBX::Mat4& vm, float sw, float sh, RBX::Vec2 center) {
        RBX::RbxInstance ch(p.characterAddr);
        RBX::Vec3 cands[3]; int n = 0;
        auto h = ch.ResolveHitPart(ch, 0, p.rootPartAddr); if (h) cands[n++] = h.GetPos();
        auto t = ch.ResolveHitPart(ch, 1, p.rootPartAddr); if (t) cands[n++] = t.GetPos();
        if (p.rootPartAddr) cands[n++] = p.position;
        float best = FLT_MAX; RBX::Vec3 out = TargetPos(p);
        for (int i = 0; i < n; i++) {
            RBX::Vec2 sp = W2S::WorldToScreen(cands[i], vm, sw, sh);
            if (sp.X == 0 && sp.Y == 0) continue;
            float d = Dist2D(center, sp);
            if (d < best) { best = d; out = cands[i]; }
        }
        return Predict(p, out);
    }

    inline void Run(const RBX::Mat4& vm, float sw, float sh) {
        if (!Vars::Aimbot::enabled) { Unlock(); toggleState = false; return; }
        if (Globals::localHealth <= 0) { Unlock(); return; } // dead-pause: never aim from a corpse
        if (!forceActive && !AimActive()) { Unlock(); return; }
        POINT mp; GetCursorPos(&mp);
        RBX::Vec2 center{(float)mp.x, (float)mp.y};
        DWORD now = GetTickCount();

        // validate existing lock every frame: dead/gone/behind-camera/max-time all drop it
        if (locked) {
            bool alive = false;
            for (auto& p : PlayerCache::players) {
                if (p.playerAddr != locked) continue;
                // death unlock: hp hit 0 since lock (kills the wall-stick after kill)
                if (Vars::Aimbot::deathUnlock && lockedLastHealth > 0 && p.health == 0) {
                    if (Vars::Misc::hitmarker) { Globals::hitmarkerUntil = now + 900; Vars::Misc::kills++; }
                    Unlock();
                    unlockUntil = now + (DWORD)(Vars::Aimbot::relockDelay * 1000);
                    break;
                }
                if (!PassesChecks(p)) break;
                if (Vars::Aimbot::maxLockTime > 0 && now - lockStart > (DWORD)(Vars::Aimbot::maxLockTime * 1000)) break;
                RBX::Vec3 tp = TargetPos(p);
                // non-sticky: drop the moment they leave the circle (closest-to-crosshair feel)
                if (!Vars::Aimbot::stickyLock) {
                    RBX::Vec2 tsp = W2S::WorldToScreen(tp, vm, sw, sh);
                    POINT tmp; GetCursorPos(&tmp);
                    if (Dist2D(center, tsp) > Vars::Aimbot::fovRadius) break;
                }
                // behind-camera-plane drop (experimental wallcheck support)
                float w = tp.X*vm.data[12]+tp.Y*vm.data[13]+tp.Z*vm.data[14]+vm.data[15];
                if (Vars::Aimbot::wallCheck && w < 0.1f) break;
                lockedLastHealth = p.health;
                alive = true;
                break;
            }
            if (!alive && locked) { Unlock(); unlockUntil = now + (DWORD)(Vars::Aimbot::relockDelay * 1000); return; }
        }

            if (!locked) {
            if (now < unlockUntil) { Globals::aimTargetAddr = 0; return; }
            float best = FLT_MAX; uintptr_t bestAddr = 0;
            for (auto& p : PlayerCache::players) {
                if (!PassesChecks(p)) continue;
                RBX::Vec3 tp = (Vars::Aimbot::hitPart == 6)
                    ? TargetPosClosest(p, vm, sw, sh, center) : TargetPos(p);
                RBX::Vec2 sp = W2S::WorldToScreen(tp, vm, sw, sh);
                if (sp.X==0&&sp.Y==0) continue;
                if (sp.X<0||sp.Y<0||sp.X>sw||sp.Y>sh) continue;
                float d = Dist2D(center, sp);
                if (d < Vars::Aimbot::fovRadius && d < best) { best = d; bestAddr = p.playerAddr; }
            }
            if (bestAddr) {
                locked = bestAddr; lockStart = now;
                for (auto& p : PlayerCache::players) if (p.playerAddr == locked) lockedLastHealth = p.health;
            } else { Globals::aimTargetAddr = 0; return; }
        }
        for (auto& p : PlayerCache::players) {
            if (p.playerAddr != locked || !PassesChecks(p)) continue;
            RBX::Vec3 tp = (Vars::Aimbot::hitPart == 6)
                ? TargetPosClosest(p, vm, sw, sh, center) : TargetPos(p);
            if (Vars::Aimbot::aimMethod == 1) {
                RBX::Vec3 camPos = Coms->ReadMemory<RBX::Vec3>(Globals::camera.Addr + offsets::CameraPos);
                if (camPos.X==0&&camPos.Y==0&&camPos.Z==0) { Unlock(); return; }
                RBX::Vec2 cur = Coms->ReadMemory<RBX::Vec2>(Globals::camera.Addr + offsets::CameraRotation);
                if (!isfinite(cur.X) || !isfinite(cur.Y) || fabsf(cur.X) > 6.29f || fabsf(cur.Y) > 6.29f) { Unlock(); return; }
                RBX::AimCameraAt(Globals::camera.Addr, camPos, tp, Vars::Aimbot::smoothing);
                Globals::aimTargetAddr = p.playerAddr;
                return;
            }
            RBX::Vec2 sp = W2S::WorldToScreen(tp, vm, sw, sh);
            if (sp.X==0&&sp.Y==0) { Unlock(); return; }
            Globals::aimTargetAddr = p.playerAddr;
            float s = 1.0f / (Vars::Aimbot::smoothing < 1.0f ? 1.0f : Vars::Aimbot::smoothing);
            MoveMouse((sp.X-mp.x)*s, (sp.Y-mp.y)*s);
            return;
        }
        Unlock();
    }

    // Target hover highlight helper for visuals.
    inline bool IsTarget(uintptr_t playerAddr) { return locked != 0 && locked == playerAddr; }
}
