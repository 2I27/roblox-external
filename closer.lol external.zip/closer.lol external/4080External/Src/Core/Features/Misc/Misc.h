#pragma once
// Misc: triggerbot (movement/fov/noclip moved to Character/Camera tabs).
#include "../../Cache/Cache.h"
#include "../../Vars/Vars.h"
#include "../../../Game/SDK/SDK.h"
#include <windows.h>

namespace Misc {
    // Rapid fire: auto-clicker while key held. *Real input via SendInput — works in any game*
    inline void RunRapidFire() {
        if (!Vars::Misc::rapidFire) return;
        int k = Vars::Misc::rapidKey;
        bool held = (k == 1) ? (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
                  : (k == 2) ? (GetAsyncKeyState(VK_RBUTTON) & 0x8000)
                  : (k >= 0 && (GetAsyncKeyState(k) & 0x8000));
        if (!held) return;
        static DWORD last = 0;
        DWORD now = GetTickCount();
        if (now - last < (DWORD)Vars::Misc::rapidIntervalMs) return;
        last = now;
        INPUT in{}; in.type = INPUT_MOUSE; in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        SendInput(1, &in, sizeof(in));
        in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
        SendInput(1, &in, sizeof(in));
    }
    inline void RunTriggerbot(const RBX::Mat4& vm, float sw, float sh) {
        bool on = Vars::Misc::triggerbot || Vars::Aimbot::triggerbot;
        if (!on) return;
        if (!(GetAsyncKeyState(VK_XBUTTON2) & 0x8000)) return;
        POINT mp; GetCursorPos(&mp);
        for (auto& p : PlayerCache::players) {
            if (!p.isValid) continue;
            if (p.teamAddr && p.teamAddr == Globals::localTeam) continue;
            RBX::RbxInstance ch(p.characterAddr);
            auto head = ch.FindChild("Head");
            if (!head) continue;
            RBX::Vec3 hp = head.GetPos();
            float w = hp.X*vm.data[0]+hp.Y*vm.data[1]+hp.Z*vm.data[2]+vm.data[3];
            float ww = hp.X*vm.data[12]+hp.Y*vm.data[13]+hp.Z*vm.data[14]+vm.data[15];
            if (ww < 0.1f) continue;
            float sx = (sw/2*(w/ww))+(sw/2);
            float hh = hp.X*vm.data[4]+hp.Y*vm.data[5]+hp.Z*vm.data[6]+vm.data[7];
            float sy = -(sh/2*(hh/ww))+(sh/2);
            if (fabsf(sx-mp.x) < 12 && fabsf(sy-mp.y) < 12) {
                static DWORD last = 0;
                if (GetTickCount() - last < (DWORD)Vars::Misc::triggerDelayMs) return;
                last = GetTickCount();
                INPUT in{}; in.type = INPUT_MOUSE; in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
                SendInput(1,&in,sizeof(in));
                in.mi.dwFlags = MOUSEEVENTF_LEFTUP;
                SendInput(1,&in,sizeof(in));
                return;
            }
        }
    }
}
