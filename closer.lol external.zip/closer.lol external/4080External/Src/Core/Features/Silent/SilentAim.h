#pragma once
// Silent aim: engages only on key, curves toward best target inside silent FOV.
// Method 0 Mouse-curve (humanized micro-steps, legit) — works everywhere.
// Method 1 Memory camlock (camera-angle write, experimental: rotation layout varies per build).
#include "../../../Game/W2S/W2S.h"
#include "../../Cache/Cache.h"
#include "../../Vars/Vars.h"
#include <windows.h>
#include <cmath>
#include <cfloat>

namespace SilentAim {
    inline bool KeyHeld() {
        int k = Vars::Silent::silentKey;
        if (k==1) return GetAsyncKeyState(VK_LBUTTON)&0x8000;
        if (k==2) return GetAsyncKeyState(VK_RBUTTON)&0x8000;
        if (k==4) return GetAsyncKeyState(VK_MBUTTON)&0x8000;
        if (k==5) return GetAsyncKeyState(VK_XBUTTON1)&0x8000;
        if (k==6) return GetAsyncKeyState(VK_XBUTTON2)&0x8000;
        return k>0 && (GetAsyncKeyState(k)&0x8000);
    }
    inline void Run(const RBX::Mat4& vm, float sw, float sh) {
        // Magic bullet preset: wide FOV + snappy curve + auto-engage while toggled.
        static float savedFov = 0, savedSmooth = 0;
        static bool savedAuto = false, hadMagic = false;
        if (Vars::Silent::magicBullet && !hadMagic) {
            savedFov = Vars::Silent::fovRadius; savedSmooth = Vars::Silent::smoothing; savedAuto = Vars::Silent::autoFire;
            Vars::Silent::fovRadius = 300.0f; Vars::Silent::smoothing = 2.0f; Vars::Silent::autoFire = true;
            hadMagic = true;
        } else if (!Vars::Silent::magicBullet && hadMagic) {
            Vars::Silent::fovRadius = savedFov; Vars::Silent::smoothing = savedSmooth; Vars::Silent::autoFire = savedAuto;
            hadMagic = false;
        }
        if (!Vars::Silent::enabled) { Globals::silentHasTarget = false; return; }
        if (Globals::localHealth <= 0) { Globals::silentHasTarget = false; return; }
        // Engagement discipline (what makes it feel like real silent aim):
        // - autoFire envelope: always hunting; onFireOnly narrows it to while firing (LMB)
        // - no autoFire: engages on the silent key
        bool firing = (GetAsyncKeyState(VK_LBUTTON) & 0x8000);
        if (Vars::Silent::autoFire) {
            if (Vars::Silent::onFireOnly && !firing) { Globals::silentHasTarget = false; return; }
        } else if (!KeyHeld()) { Globals::silentHasTarget = false; return; }
        POINT mp; GetCursorPos(&mp);
        float best = FLT_MAX;
        RBX::Vec3 bestPos{};
        bool found = false;
        for (auto& p : PlayerCache::players) {
            if (!p.isValid) continue;
            if (p.teamAddr && p.teamAddr == Globals::localTeam) continue;
            if (p.health <= 0) continue;
            if (Vars::Silent::knockCheck && p.knocked) continue;
            if (Vars::Silent::distance > 0 && p.distance > Vars::Silent::distance) continue;
            RBX::RbxInstance ch(p.characterAddr);
            auto part = ch.ResolveHitPart(ch, Vars::Silent::hitPart == 0 ? 0 : 1, p.rootPartAddr);
            RBX::Vec3 tp = part ? part.GetPos() : p.position;
            float t = Vars::Silent::prediction;
            if (t > 0) { tp.X += p.velocity.X*t; tp.Y += p.velocity.Y*t; tp.Z += p.velocity.Z*t; }
            RBX::Vec2 sp = W2S::WorldToScreen(tp, vm, sw, sh);
            if (sp.X==0&&sp.Y==0) continue;
            if (sp.X<0||sp.Y<0||sp.X>sw||sp.Y>sh) continue;
            float dx = sp.X-mp.x, dy = sp.Y-mp.y;
            float d = sqrtf(dx*dx+dy*dy);
            if (d < Vars::Silent::fovRadius && d < best) { best = d; bestPos = tp; found = true; }
        }
        if (!found) { Globals::silentHasTarget = false; return; }
        Globals::silentHasTarget = true;
        {
            RBX::Vec2 ssp = W2S::WorldToScreen(bestPos, vm, sw, sh);
            Globals::silentAimScreen = ssp;
        }
        if (Vars::Silent::method == 1) {
            if (!Globals::camera) return;
            RBX::Vec3 camPos = Coms->ReadMemory<RBX::Vec3>(Globals::camera.Addr + offsets::CameraPos);
            if (camPos.X==0&&camPos.Y==0&&camPos.Z==0) return;
            // validate rotation read before writing: both floats must be finite and small
            RBX::Vec2 cur = Coms->ReadMemory<RBX::Vec2>(Globals::camera.Addr + offsets::CameraRotation);
            if (!isfinite(cur.X) || !isfinite(cur.Y) || fabsf(cur.X) > 6.29f || fabsf(cur.Y) > 6.29f) return;
            RBX::AimCameraAt(Globals::camera.Addr, camPos, bestPos, Vars::Silent::smoothing);
            return;
        }
        // mouse curve: capped micro-steps per frame — visible, smooth, legit at high smoothing
        RBX::Vec2 sp = W2S::WorldToScreen(bestPos, vm, sw, sh);
        float dx = sp.X - mp.x, dy = sp.Y - mp.y;
        float step = 1.0f / (Vars::Silent::smoothing < 1.0f ? 1.0f : Vars::Silent::smoothing);
        float mx = dx * step, my = dy * step;
        float cap = 30.0f; // never snap more than 30px/frame — the "legit" guarantee
        if (mx > cap) mx = cap; if (mx < -cap) mx = -cap;
        if (my > cap) my = cap; if (my < -cap) my = -cap;
        if (fabsf(mx) < 0.5f && fabsf(my) < 0.5f) return;
        INPUT in{}; in.type = INPUT_MOUSE; in.mi.dwFlags = MOUSEEVENTF_MOVE;
        in.mi.dx = (LONG)mx; in.mi.dy = (LONG)my;
        SendInput(1, &in, sizeof(in));
    }
    inline void DrawFOV(ImDrawList* dl, ImU32 acc) {
        if (!Vars::Silent::enabled || !Vars::Silent::showFOV) return;
        POINT mp; GetCursorPos(&mp);
        int seg = 24 + (int)(Vars::Silent::fovSmooth * 8.0f);
        ImVec2 c((float)mp.x, (float)mp.y);
        if (Vars::Silent::fillFOV) dl->AddCircleFilled(c, Vars::Silent::fovRadius, IM_COL32(255,255,255,25), seg);
        dl->AddCircle(c, Vars::Silent::fovRadius, IM_COL32(0,0,0,255), seg, 2.0f);
        dl->AddCircle(c, Vars::Silent::fovRadius, acc, seg, 1.0f);
    }
}
