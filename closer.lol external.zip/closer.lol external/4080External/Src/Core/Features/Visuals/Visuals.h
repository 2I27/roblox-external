#pragma once
// language: C++, file: 4080External/Src/Core/Features/Visuals/Visuals.h
#include "../../../Game/W2S/W2S.h"
#include "../../Cache/Cache.h"
#include "../../Vars/Vars.h"
#include "../../../Render/ImGui/imgui.h"
#include <string>
#include <algorithm>
#include <cmath>

namespace Visuals {
    inline int lastBoxes = 0; // selftest: boxes projected last frame
    inline void OutlinedText(ImDrawList* d, const ImVec2& p, const std::string& t, ImU32 c) {
        d->AddText(ImVec2(p.x-1,p.y), IM_COL32(0,0,0,255), t.c_str());
        d->AddText(ImVec2(p.x+1,p.y), IM_COL32(0,0,0,255), t.c_str());
        d->AddText(ImVec2(p.x,p.y-1), IM_COL32(0,0,0,255), t.c_str());
        d->AddText(ImVec2(p.x,p.y+1), IM_COL32(0,0,0,255), t.c_str());
        d->AddText(p, c, t.c_str());
    }

    inline void BoundsForCharacter(RBX::RbxInstance ch, bool r6, RBX::Vec3* pts, int* n) {
        *n = 0;
        auto push = [&](const RBX::Vec3& v){ if (*n < 200) pts[(*n)++] = v; };
        RBX::RbxInstance head = ch.FindChild("Head");
        RBX::RbxInstance torso = r6 ? ch.FindChild("Torso") : ch.FindChild("UpperTorso");
        if (!head || !torso) return;
        auto hp = head.GetPos();
        float hs = r6 ? 1.0f : 0.8f;
        for (int i = 0; i < 8; i++) {
            float a = (i/8.0f)*6.28318f;
            push({hp.X+cosf(a)*hs, hp.Y, hp.Z+sinf(a)*hs});
        }
        push({hp.X, hp.Y+hs, hp.Z});
        auto cf = torso.GetCFrame();
        auto tp = cf.Pos(), tr = cf.Right(), tu = cf.Up(), tl = cf.Look();
        float W = r6?2.0f:1.6f, H = r6?2.0f:1.5f, D = r6?1.0f:0.8f;
        // torso box
        for (int x=-1;x<=1;x+=2) for(int y=-1;y<=1;y+=2) for(int z=-1;z<=1;z+=2)
            push({tp.X+tr.X*(x*W*.5f)+tu.X*(y*H*.5f)+tl.X*(z*D*.5f),
                  tp.Y+tr.Y*(x*W*.5f)+tu.Y*(y*H*.5f)+tl.Y*(z*D*.5f),
                  tp.Z+tr.Z*(x*W*.5f)+tu.Z*(y*H*.5f)+tl.Z*(z*D*.5f)});
        // limbs: sample CFrame centers only (cheap, stable)
        const char* limbsR6[] = {"Left Arm","Right Arm","Left Leg","Right Leg"};
        const char* limbsR15[] = {"LeftHand","RightHand","LeftFoot","RightFoot","LeftLowerArm","RightLowerArm","LeftLowerLeg","RightLowerLeg"};
        if (r6) { for (auto nm : limbsR6) { auto l = ch.FindChild(nm); if (l) push(l.GetPos()); } }
        else { for (auto nm : limbsR15) { auto l = ch.FindChild(nm); if (l) push(l.GetPos()); } }
    }

    inline void RenderESP(ImDrawList* drawList, const RBX::Mat4& vm, float sw, float sh) {
        lastBoxes = 0;
        if (!Vars::ESP::enabled) return;
        for (auto& plr : PlayerCache::players) {
            if (!plr.isValid) continue;
            if (Vars::ESP::distance > 0 && plr.distance > Vars::ESP::distance) continue;
            if (Vars::ESP::teamCheck && plr.teamAddr && plr.teamAddr == Globals::localTeam) continue;
            bool isTarget = Vars::Aimbot::targetHover && Globals::aimTargetAddr == plr.playerAddr;
            ImU32 boxCol = isTarget ? IM_COL32(255,80,120,255) : IM_COL32(255,255,255,255);
            RBX::RbxInstance ch(plr.characterAddr);
            bool isR6 = ch.FindChild("Torso").Addr != 0;
            RBX::Vec3 pts[200]; int n = 0;
            BoundsForCharacter(ch, isR6, pts, &n);
            if (n < 3) continue;
            float minX=1e9f, minY=1e9f, maxX=-1e9f, maxY=-1e9f; int valid=0;
            for (int i=0;i<n;i++) {
                auto s = W2S::WorldToScreen(pts[i], vm, sw, sh);
                if (s.X==0&&s.Y==0) continue;
                minX=(std::min)(minX,s.X); minY=(std::min)(minY,s.Y);
                maxX=(std::max)(maxX,s.X); maxY=(std::max)(maxY,s.Y); valid++;
            }
            if (valid<3) continue;
            if ((maxX-minX) > sw*1.5f || (maxY-minY) > sh*1.5f) continue;

            if (Vars::ESP::boxes) {
                lastBoxes++;
                if (Vars::ESP::outline) drawList->AddRect(ImVec2(minX-1,minY-1), ImVec2(maxX+1,maxY+1), IM_COL32(0,0,0,255), 0, 0, 3.0f);
                if (Vars::ESP::fillBox) drawList->AddRectFilled(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(255,255,255,(int)(255*Vars::ESP::fillAlpha)));
                if (Vars::ESP::chamsFilled) drawList->AddRectFilled(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(150,110,255,70));
                drawList->AddRect(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(0,0,0,255), 0, 0, 3.0f);
                drawList->AddRect(ImVec2(minX,minY), ImVec2(maxX,maxY), boxCol, 0, 0, 1.0f);
                // chams: overlay glow frame (Ghost = soft accent edge, Glow = bright + halo)
                if (Vars::ESP::chams) {
                    if (Vars::ESP::chamMode == 1) {
                        drawList->AddRect(ImVec2(minX-3,minY-3), ImVec2(maxX+3,maxY+3), IM_COL32(150,110,255,90), 0, 0, 3.0f);
                        drawList->AddRect(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(190,150,255,255), 0, 0, 1.5f);
                    } else {
                        drawList->AddRect(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(150,110,255,140), 0, 0, 1.0f);
                    }
                }
            }
            if (Vars::ESP::healthBar && plr.maxHealth > 0) {
                float pct = std::clamp(plr.health/plr.maxHealth, 0.0f, 1.0f);
                drawList->AddRectFilled(ImVec2(minX-6,minY), ImVec2(minX-2,maxY), IM_COL32(0,0,0,200));
                drawList->AddRectFilled(ImVec2(minX-5,maxY-(maxY-minY)*pct), ImVec2(minX-3,maxY),
                    IM_COL32((int)(255*(1-pct)), (int)(255*pct), 0, 255));
            }
            if (Vars::ESP::names) {
                const std::string& nm = (Vars::ESP::nameMode == 1 && !plr.displayName.empty()) ? plr.displayName : plr.name;
                ImVec2 ts = ImGui::CalcTextSize(nm.c_str());
                OutlinedText(drawList, ImVec2((minX+maxX)/2-ts.x/2, minY-ts.y-2), nm, IM_COL32(255,255,255,255));
            }
            if (Vars::ESP::distanceText) {
                std::string dt = std::to_string((int)plr.distance)+"m";
                ImVec2 ts = ImGui::CalcTextSize(dt.c_str());
                OutlinedText(drawList, ImVec2((minX+maxX)/2-ts.x/2, maxY+2), dt, IM_COL32(200,200,200,255));
            }
            if (!plr.tool.empty() && Vars::ESP::equipped) {
                ImVec2 ts = ImGui::CalcTextSize(plr.tool.c_str());
                OutlinedText(drawList, ImVec2((minX+maxX)/2-ts.x/2, maxY+16), plr.tool, IM_COL32(255,220,120,255));
            }
            if (Vars::ESP::headDot && plr.headAddr) {
                RBX::Vec3 hp = RBX::RbxInstance(plr.headAddr).GetPos();
                RBX::Vec2 hs = W2S::WorldToScreen(hp, vm, sw, sh);
                if (!(hs.X==0&&hs.Y==0)) drawList->AddCircleFilled(ImVec2(hs.X,hs.Y), 3.0f, IM_COL32(255,80,120,255), 12);
            }
            if (Vars::ESP::tracerMode > 0) {
                ImVec2 from(sw/2, sh);
                if (Vars::ESP::tracerMode == 2) from = ImVec2(sw/2, 0);
                else if (Vars::ESP::tracerMode == 3) from = ImVec2(sw/2, sh/2);
                else if (Vars::ESP::tracerMode == 4) { POINT mp; GetCursorPos(&mp); from = ImVec2((float)mp.x,(float)mp.y); }
                drawList->AddLine(from, ImVec2((minX+maxX)/2, maxY), IM_COL32(255,255,255,120), 1.0f);
            }
            if (Vars::ESP::skeleton) {
                auto proj = [&](RBX::RbxInstance part, ImVec2& out) -> bool {
                    if (!part) return false;
                    RBX::Vec2 s = W2S::WorldToScreen(part.GetPos(), vm, sw, sh);
                    if (s.X==0&&s.Y==0) return false;
                    out = ImVec2(s.X, s.Y); return true;
                };
                const char* jointsR6[] = {"Head","Torso","Left Arm","Right Arm","Left Leg","Right Leg"};
                const char* jointsR15[] = {"Head","UpperTorso","LowerTorso","LeftHand","RightHand","LeftFoot","RightFoot"};
                ImVec2 H, UT, LT, LA, RA, LL, RL;
                bool ok = false;
                if (isR6) {
                    ImVec2 T, LArm, RArm, LLeg, RLeg;
                    if (proj(ch.FindChild("Head"), H) && proj(ch.FindChild("Torso"), T) &&
                        proj(ch.FindChild("Left Arm"), LArm) && proj(ch.FindChild("Right Arm"), RArm) &&
                        proj(ch.FindChild("Left Leg"), LLeg) && proj(ch.FindChild("Right Leg"), RLeg)) {
                        drawList->AddLine(H, T, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(T, LArm, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(T, RArm, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(T, LLeg, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(T, RLeg, IM_COL32(0,255,170,255), 1.5f);
                        ok = true;
                    }
                    (void)ok; (void)jointsR6;
                } else {
                    if (proj(ch.FindChild("Head"), H) && proj(ch.FindChild("UpperTorso"), UT) &&
                        proj(ch.FindChild("LowerTorso"), LT) && proj(ch.FindChild("LeftHand"), LA) &&
                        proj(ch.FindChild("RightHand"), RA) && proj(ch.FindChild("LeftFoot"), LL) &&
                        proj(ch.FindChild("RightFoot"), RL)) {
                        drawList->AddLine(H, UT, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(UT, LT, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(UT, LA, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(UT, RA, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(LT, LL, IM_COL32(0,255,170,255), 1.5f);
                        drawList->AddLine(LT, RL, IM_COL32(0,255,170,255), 1.5f);
                    }
                    (void)jointsR15;
                }
            }
        }
    }

    // Self ESP: box around your own character from the local model.
    inline void DrawSelfESP(ImDrawList* drawList, const RBX::Mat4& vm, float sw, float sh) {
        if (!Vars::ESP::selfESP || !Globals::localPlayer) return;
        auto ch = Globals::localPlayer.GetModelRef();
        if (!ch) return;
        bool isR6 = ch.FindChild("Torso").Addr != 0;
        RBX::Vec3 pts[200]; int n = 0;
        BoundsForCharacter(ch, isR6, pts, &n);
        if (n < 3) return;
        float minX=1e9f, minY=1e9f, maxX=-1e9f, maxY=-1e9f; int valid=0;
        for (int i=0;i<n;i++) {
            auto s = W2S::WorldToScreen(pts[i], vm, sw, sh);
            if (s.X==0&&s.Y==0) continue;
            minX=(std::min)(minX,s.X); minY=(std::min)(minY,s.Y);
            maxX=(std::max)(maxX,s.X); maxY=(std::max)(maxY,s.Y); valid++;
        }
        if (valid<3) return;
        drawList->AddRect(ImVec2(minX,minY), ImVec2(maxX,maxY), IM_COL32(80,255,140,255), 0, 0, 1.5f);
        OutlinedText(drawList, ImVec2((minX+maxX)/2-10, minY-16), "YOU", IM_COL32(80,255,140,255));
    }

    // Top-right radar: local player centered, blips scaled by zoom.
    inline void DrawRadar(ImDrawList* dl, float sw) {
        if (!Vars::ESP::radar) return;
        float sz = Vars::ESP::radarSize, z = Vars::ESP::radarZoom;
        ImVec2 o(sw - sz - 12, 50);
        dl->AddRectFilled(o, ImVec2(o.x+sz, o.y+sz), IM_COL32(5,5,10,200));
        dl->AddRect(o, ImVec2(o.x+sz, o.y+sz), IM_COL32(255,255,255,80));
        dl->AddLine(ImVec2(o.x+sz/2, o.y), ImVec2(o.x+sz/2, o.y+sz), IM_COL32(255,255,255,30));
        dl->AddLine(ImVec2(o.x, o.y+sz/2), ImVec2(o.x+sz, o.y+sz/2), IM_COL32(255,255,255,30));
        dl->AddCircleFilled(ImVec2(o.x+sz/2, o.y+sz/2), 3.0f, IM_COL32(80,255,140,255), 10);
        for (auto& p : PlayerCache::players) {
            if (!p.isValid) continue;
            float dx = (p.position.X - PlayerCache::localPlayerPos.X) * z;
            float dz = (p.position.Z - PlayerCache::localPlayerPos.Z) * z;
            float bx = o.x + sz/2 + dx, by = o.y + sz/2 + dz;
            if (bx < o.x || bx > o.x+sz || by < o.y || by > o.y+sz) continue;
            bool foe = !(p.teamAddr && p.teamAddr == Globals::localTeam);
            dl->AddCircleFilled(ImVec2(bx,by), 2.5f, foe ? IM_COL32(255,80,120,255) : IM_COL32(80,200,255,255), 8);
        }
        OutlinedText(dl, ImVec2(o.x, o.y - 16), "closer.lol radar", IM_COL32(255,255,255,200));
    }
}
