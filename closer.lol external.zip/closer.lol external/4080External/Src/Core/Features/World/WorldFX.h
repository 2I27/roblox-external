#pragma once
// World + Character live effects.
#include "../../Cache/Cache.h"
#include "../../Vars/Vars.h"
#include "../../../Game/SDK/SDK.h"
#include <windows.h>
#include <cmath>

namespace WorldFX {
    inline RBX::RbxInstance Lighting() {
        static uintptr_t cache = 0;
        static int tick = 0;
        if (++tick % 300 == 0) cache = 0;
        if (!cache) cache = Globals::dataModel.FindChildByClass("Lighting").Addr;
        return RBX::RbxInstance(cache);
    }
    inline void Run() {
        auto li = Lighting();
        if (li) {
            if (Vars::World::customFog || Vars::World::noFog) {
                float fs = Vars::World::noFog ? 100000.0f : 50.0f;
                float fe = Vars::World::noFog ? 100000.0f : 500.0f;
                Coms->WriteMemory<float>(li.Addr + offsets::FogStartL, fs);
                Coms->WriteMemory<float>(li.Addr + offsets::FogEndL, fe);
                if (Vars::World::customFog) {
                    struct C3 { float r,g,b; };
                    C3 c{Vars::World::fogColor[0], Vars::World::fogColor[1], Vars::World::fogColor[2]};
                    Coms->WriteMemory<C3>(li.Addr + offsets::FogColorL, c);
                }
            }
            if (Vars::World::glow || Vars::World::fullbright) {
                struct C3 { float r,g,b; };
                C3 amb{1,1,1}, out{1,1,1};
                Coms->WriteMemory<C3>(li.Addr + offsets::AmbientL, amb);
                Coms->WriteMemory<C3>(li.Addr + offsets::OutdoorAmbientL, out);
                Coms->WriteMemory<float>(li.Addr + offsets::BrightnessL, 2.0f);
            }
        }
        // Camera FOV: validate the read first — never write blind.
        // A wrong FOV offset used to write garbage and wreck the camera ("breaks game").
        if (Globals::camera) {
            static float lastWrote = 0;
            if (Vars::Camera::fovChanger) {
                float cur = Coms->ReadMemory<float>(Globals::camera.Addr + offsets::FOV);
                if (cur >= 20.0f && cur <= 130.0f) {
                    float want = Vars::Camera::customFOV;
                    if (want < 30) want = 30; if (want > 120) want = 120;
                    if (fabsf(cur - want) > 0.5f) { Coms->WriteMemory<float>(Globals::camera.Addr + offsets::FOV, want); lastWrote = want; }
                }
            } else if (lastWrote != 0) {
                Coms->WriteMemory<float>(Globals::camera.Addr + offsets::FOV, 70.0f);
                lastWrote = 0;
            }
            // Third person: write zoom limits only on change, restore on disable.
            static float lastZoom = 0;
            if (Vars::Camera::thirdPerson && Globals::localPlayer) {
                float curMin = Coms->ReadMemory<float>(Globals::localPlayer.Addr + offsets::CamMinZoom);
                if (curMin >= 0 && curMin < 500 && fabsf(curMin - Vars::Camera::thirdDist) > 0.5f) {
                    Coms->WriteMemory<float>(Globals::localPlayer.Addr + offsets::CamMinZoom, Vars::Camera::thirdDist);
                    Coms->WriteMemory<float>(Globals::localPlayer.Addr + offsets::CamMaxZoom, Vars::Camera::thirdDist);
                    lastZoom = Vars::Camera::thirdDist;
                }
            } else if (lastZoom != 0 && Globals::localPlayer) {
                Coms->WriteMemory<float>(Globals::localPlayer.Addr + offsets::CamMinZoom, 0.5f);
                Coms->WriteMemory<float>(Globals::localPlayer.Addr + offsets::CamMaxZoom, 12.0f);
                lastZoom = 0;
            }
        }
    }
}

namespace CharFX {
    inline void KeyTap(int vk);
    inline void RunHvHMove(uintptr_t prim);
    inline void Run() {
        auto ch = Globals::localPlayer.GetModelRef();
        if (!ch) return;
        auto root = ch.FindChild("HumanoidRootPart");
        if (!root) return;
        uintptr_t prim = Coms->ReadMemory<uintptr_t>(root.Addr + offsets::Primitive);
        if (!prim) return;
        auto hum = ch.FindChildByClass("Humanoid");
        if (hum) {
            if (Vars::Character::speedEnabled) RBX::SetWalkSpeed(hum.Addr, Vars::Character::walkSpeed);
            if (Vars::Character::jumpEnabled) RBX::SetJumpPower(hum.Addr, Vars::Character::jumpPower);
        }
        // Anti-fling: clamp insane local velocity (fling = thousands of studs/s)
        if (Vars::Character::antiFling) {
            RBX::Vec3 v = Coms->ReadMemory<RBX::Vec3>(prim + offsets::Velocity);
            float m = sqrtf(v.X*v.X + v.Y*v.Y + v.Z*v.Z);
            if (m > 250.0f) { RBX::Vec3 z{0,0,0}; Coms->WriteMemory<RBX::Vec3>(prim + offsets::Velocity, z); }
        }
        // Noclip
        {
            static bool wasOn = false;
            if (Vars::Character::noclip != wasOn) {
                std::vector<RBX::RbxInstance> parts; ch.CollectParts(parts);
                for (auto& p : parts) RBX::SetPartCollide(p.Addr, !Vars::Character::noclip);
                wasOn = Vars::Character::noclip;
            } else if (Vars::Character::noclip) {
                RBX::SetPartCollide(root.Addr, false);
            }
        }
        // Fly v2 (camera-relative, hold key)
        if (Vars::Character::flyEnabled && (GetAsyncKeyState(Vars::Character::flyKey) & 0x8000)) {
            RBX::Vec3 pos = Coms->ReadMemory<RBX::Vec3>(prim + offsets::Position);
            RBX::CFrame ccf = Coms->ReadMemory<RBX::CFrame>(Globals::camera.Addr + offsets::CFrame);
            RBX::Vec3 look{-ccf.data[2], -ccf.data[5], -ccf.data[8]};
            RBX::Vec3 right{ccf.data[0], ccf.data[3], ccf.data[6]};
            float step = Vars::Character::flySpeed * 0.016f;
            if (GetAsyncKeyState(0x57)&0x8000) { pos.X+=look.X*step; pos.Y+=look.Y*step; pos.Z+=look.Z*step; }
            if (GetAsyncKeyState(0x53)&0x8000) { pos.X-=look.X*step; pos.Y-=look.Y*step; pos.Z-=look.Z*step; }
            if (GetAsyncKeyState(0x41)&0x8000) { pos.X-=right.X*step; pos.Z-=right.Z*step; }
            if (GetAsyncKeyState(0x44)&0x8000) { pos.X+=right.X*step; pos.Z+=right.Z*step; }
            if (GetAsyncKeyState(VK_SPACE)&0x8000) pos.Y += step;
            if (GetAsyncKeyState(VK_SHIFT)&0x8000) pos.Y -= step;
            Coms->WriteMemory<RBX::Vec3>(prim + offsets::Position, pos);
        }
        // Float: lock height
        if (Vars::Character::floatEnabled) {
            RBX::Vec3 pos = Coms->ReadMemory<RBX::Vec3>(prim + offsets::Position);
            if (Vars::Character::floatY == 0) Vars::Character::floatY = pos.Y;
            pos.Y = Vars::Character::floatY;
            if (GetAsyncKeyState(VK_SPACE)&0x8000) { pos.Y += 1.0f; Vars::Character::floatY = pos.Y; }
            if (GetAsyncKeyState(VK_SHIFT)&0x8000) { pos.Y -= 1.0f; Vars::Character::floatY = pos.Y; }
            Coms->WriteMemory<RBX::Vec3>(prim + offsets::Position, pos);
        } else Vars::Character::floatY = 0;
        RunHvHMove(prim);
    }

    // HvH movement: bhop (space spam), autostrafe (A/D alternate), edgejump (jump on ground-loss).
    // *Key simulation via SendInput — game sees real input, no memory writes involved*
    inline void KeyTap(int vk) {
        INPUT d{}; d.type = INPUT_KEYBOARD; d.ki.wVk = (WORD)vk;
        SendInput(1, &d, sizeof(d));
        d.ki.dwFlags = KEYEVENTF_KEYUP;
        SendInput(1, &d, sizeof(d));
    }
    inline void RunHvHMove(uintptr_t prim) {
        RBX::Vec3 v = Coms->ReadMemory<RBX::Vec3>(prim + offsets::Velocity);
        bool air = fabsf(v.Y) > 1.5f;
        DWORD now = GetTickCount();
        static DWORD lastJump = 0, lastStrafe = 0;
        static bool strafeSide = false, wasAir = false;
        if (Vars::HvH::bhop && (GetAsyncKeyState(Vars::HvH::bhopKey) & 0x8000)) {
            if (!air && now - lastJump > 30) { KeyTap(VK_SPACE); lastJump = now; }
        }
        if (Vars::HvH::autostrafe && air && now - lastStrafe > 60) {
            strafeSide = !strafeSide;
            KeyTap(strafeSide ? 0x41 : 0x44);
            lastStrafe = now;
        }
        if (Vars::HvH::edgejump) {
            if (wasAir == false && air) {
                // just left ground: falling = edge walked off
                if (v.Y < -2.0f && now - lastJump > 200) { KeyTap(VK_SPACE); lastJump = now; }
            }
        }
        wasAir = air;
    }
}
