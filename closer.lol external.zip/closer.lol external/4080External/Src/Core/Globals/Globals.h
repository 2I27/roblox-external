#pragma once
// language: C++, file: 4080External/Src/Core/Globals/Globals.h
#include "../../Game/SDK/SDK.h"
namespace Globals {
    inline RBX::RbxInstance dataModel(0);
    inline RBX::RenderEngine renderEngine(0);
    inline RBX::RbxInstance workspace(0);
    inline RBX::RbxInstance players(0);
    inline RBX::RbxInstance camera(0);
    inline RBX::RbxInstance localPlayer(0);
    inline uintptr_t localTeam = 0;
    inline uintptr_t aimTargetAddr = 0;
    inline float localHealth = 100.0f;
    inline RBX::Vec2 silentAimScreen{0, 0};
    inline bool silentHasTarget = false;
    inline DWORD hitmarkerUntil = 0;
    inline std::string offsetVersion = "compiled-in";
}
