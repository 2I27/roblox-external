#pragma once
// closer.lol settings — every field bound to a working control. No dead weight.
namespace Vars {
    inline bool menuOpen = true;
    inline int selectedTab = 0; // 0 Aim, 1 Silent, 2 Visuals, 3 Movement, 4 World, 5 Misc, 6 Config

    namespace Aimbot {
        inline bool enabled = false;
        inline bool toggle = false;       // press-once lock vs hold-key
        inline bool stickyLock = true;    // keep lock when target leaves circle briefly
        inline bool teamCheck = true;
        inline bool healthCheck = true;   // skip dead (hp<=0)
        inline bool knockCheck = false;   // skip knocked (humanoid state, experimental)
        inline bool wallCheck = false;    // drop targets behind camera plane (experimental)
        inline bool deathUnlock = true;   // instant unlock when target dies (no wall-sticking)
        inline float maxLockTime = 5.0f;  // seconds before forced relock (0 = infinite)
        inline float relockDelay = 0.15f; // pause after unlock before picking new target
        inline bool showFOV = true;
        inline bool fillFOV = false;
        inline float fovRadius = 120.0f;
        inline float fovSmooth = 1.0f;    // circle edge segments
        inline float smoothing = 6.0f;    // lower = snappier. Applied as delta/smoothing per frame
        inline float distance = 0.0f;     // max metres, 0 = unlimited
        inline float prediction = 0.0f;   // seconds of velocity lead (0.12 good for DaHood)
        inline int hitPart = 0;           // 0 Head 1 Torso 2 LArm 3 RArm 4 LLeg 5 RLeg 6 Closest
        inline int aimMethod = 0;         // 0 Mouse 1 Memory camlock (experimental)
        inline bool triggerbot = false;
        inline bool targetHover = false;  // highlight current target box
        inline int aimbotKey = 2;         // RMB
    }
    namespace Silent {
        inline bool enabled = false;
        inline bool autoFire = false;     // engage with no key whenever a target is in FOV
        inline bool onFireOnly = true;    // with Auto: only curve while firing (LMB)
        inline bool magicBullet = false;  // preset: FOV 300 + smoothing 2 + auto on (restores after)
        inline bool wallCheck = false;
        inline bool knockCheck = false;
        inline bool showFOV = true;
        inline bool showSnapline = true;  // line to current silent target (proof it's working)
        inline bool fillFOV = false;
        inline float fovRadius = 100.0f;
        inline float fovSmooth = 1.0f;
        inline float smoothing = 8.0f;    // curve strength: higher = more legit
        inline float distance = 0.0f;
        inline float prediction = 0.12f;
        inline int hitPart = 0;           // 0 Head 1 Body
        inline int method = 0;            // 0 Mouse curve (works) 1 Memory camlock (experimental)
        inline int silentKey = 6;         // X2
    }
    namespace ESP {
        inline bool enabled = false;
        inline bool teamCheck = true;
        inline bool outline = false;
        inline bool selfESP = false;      // draw your own box too
        inline float distance = 0.0f;     // 0 = unlimited
        inline bool boxes = true;
        inline bool fillBox = false;
        inline float fillAlpha = 0.25f;
        inline bool names = true;
        inline int nameMode = 0;          // 0 Username 1 Display
        inline bool healthBar = true;
        inline bool distanceText = true;
        inline bool equipped = false;     // held tool name under box
        inline bool skeleton = false;
        inline bool headDot = false;
        inline bool chams = false;        // extra glow frame on boxes
        inline int chamMode = 0;          // 0 Ghost (subtle) 1 Glow (bright + halo)
        inline bool chamsFilled = false;  // tint the box fill with accent
        inline int tracerMode = 0;        // 0 Off 1 Bottom 2 Top 3 Middle 4 Mouse
        inline bool radar = false;
        inline float radarSize = 150.0f;
        inline float radarZoom = 1.0f;
    }
    namespace Camera {
        inline bool thirdPerson = false;
        inline float thirdDist = 12.0f;
        inline bool fovChanger = false;
        inline float customFOV = 80.0f;
    }
    namespace World {
        inline bool customFog = false;
        inline float fogColor[3] = {0.5f, 0.1f, 0.8f};
        inline bool glow = false;         // ambient boost
        inline bool fullbright = false;
        inline bool noFog = false;
    }
    namespace Character {
        inline bool antiFling = false;    // clamp insane local velocity
        inline bool noclip = false;
        inline bool speedEnabled = false;
        inline float walkSpeed = 32.0f;
        inline bool flyEnabled = false;
        inline float flySpeed = 50.0f;
        inline int flyKey = 0x46;         // F, hold + WASD/Space/Shift
        inline bool jumpEnabled = false;
        inline float jumpPower = 75.0f;
        inline bool floatEnabled = false; // hover at locked height
        inline float floatY = 0.0f;
    }
    namespace Waypoints {
        struct Slot { float x = 0, y = 0, z = 0; bool set = false; };
        inline Slot slot[5] = {};
    }
    namespace Misc {
        inline bool crosshair = false;
        inline bool triggerbot = false;   // fires when cursor sits on a head (hold X2)
        inline int triggerDelayMs = 80;
        inline bool rapidFire = false;    // auto-clicker while key held
        inline int rapidKey = 1;
        inline int rapidIntervalMs = 50;
        inline bool hitmarker = true;     // red X on kill confirm
        inline bool hitSound = false;     // beep on kill confirm
        inline bool playerList = false;   // side window: name hp dist
        inline int panicKey = 0x78;       // F9: everything off + menu hidden
        inline int kills = 0;
    }
    namespace HvH {
        inline bool backtrack = false;    // aim at 50-400ms-old records (beats jitter)
        inline float backtrackMs = 200.0f;
        inline bool bhop = false;         // space spam while held + grounded
        inline int bhopKey = 0x20;        // SPACE
        inline bool autostrafe = false;   // alternate A/D in air
        inline bool edgejump = false;     // jump the moment you leave ground
    }
    namespace Style {
        inline float accent[3] = {0.65f, 0.4f, 1.0f};
        inline bool streamproof = true;   // hide overlay from Discord/OBS capture
        inline bool hideConsole = true;   // hide console window after session connects
    }
}
