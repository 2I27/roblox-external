#pragma once
// language: C++, file: 4080External/Src/Game/Offsets/Offsets.h, runtime: Windows 11 x64, MSVC v143+, C++20
// *WinHTTP auto-update: no external deps beyond winhttp.lib — fetch fails silently, falls back to compiled-in offsets below*
#include <cstdint>
#include <string>
#include <windows.h>
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")

// Fresh dump: version-cec3ad5889b447cf, dumped 06/10/2026 (RbxDumperV2 2.2.4)
// Source: https://offsets.imtheo.lol/offsets.json
namespace offsets {
    // ---- compiled-in fallback (fresh 06/10/2026) ----
    inline constexpr uintptr_t FakeDataModelPointer = 0x8C28270;   // 146603344
    inline constexpr uintptr_t FakeDataModelToDataModel = 0x1F8;   // 504
    inline constexpr uintptr_t VisualEnginePointer = 0x86593C0;    // 140865088
    inline constexpr uintptr_t TaskSchedulerPointer = 0x8C1B5A8;  // 146247976
    inline constexpr uintptr_t ViewMatrix = 0x1B0;                 // 432 (VisualEngine->ViewMatrix)
    inline constexpr uintptr_t VisualEngineDimensions = 0xB10;     // 2832
    inline constexpr uintptr_t RenderViewFromVE = 0xC30;           // 3120

    inline constexpr uintptr_t Name = 0x8;               // Instance->Name (via NameContainer 0x70)
    inline constexpr uintptr_t NameContainer = 0x70;
    inline constexpr uintptr_t Children = 0x78;          // Instance->ChildrenStart 120
    inline constexpr uintptr_t ChildrenEnd = 0x8;
    inline constexpr uintptr_t Parent = 0x68;            // 104
    inline constexpr uintptr_t ClassDescriptor = 0x18;
    inline constexpr uintptr_t ClassDescriptorToClassName = 0x8;

    inline constexpr uintptr_t LocalPlayer = 0x120;      // Player->LocalPlayer 288
    inline constexpr uintptr_t ModelInstance = 0x288;    // Player->ModelInstance 648
    inline constexpr uintptr_t UserId = 0xC0;            // 192
    inline constexpr uintptr_t Team = 0x2C8;             // 712
    inline constexpr uintptr_t PlayerMouse = 0x1208;     // 4616

    inline constexpr uintptr_t Health = 0x180;           // Humanoid->Health 384 (float!)
    inline constexpr uintptr_t MaxHealth = 0x198;        // 408 (float!)
    inline constexpr uintptr_t WalkSpeed = 0x1C0;        // 448 (float)
    inline constexpr uintptr_t WalkSpeedCheck = 0x39C;   // 924 (float)
    inline constexpr uintptr_t JumpPower = 0x194;        // 404 (float)
    inline constexpr uintptr_t HipHeight = 0x184;        // 388
    inline constexpr uintptr_t RigType = 0x1B0;          // 432
    inline constexpr uintptr_t HumanoidState = 0x8A8;    // 2216
    inline constexpr uintptr_t HumanoidStateId = 0x20;
    inline constexpr uintptr_t MoveDirection = 0x130;    // 304
    inline constexpr uintptr_t HRPFromHumanoid = 0x460;  // 1120

    inline constexpr uintptr_t Primitive = 0x178;        // BasePart->Primitive 376
    inline constexpr uintptr_t Position = 0xD4;          // Primitive->Position 212
    inline constexpr uintptr_t Velocity = 0xE0;          // AssemblyLinearVelocity 224
    inline constexpr uintptr_t PartSize = 0x1BC;         // Primitive->Size 444
    inline constexpr uintptr_t CFrame = 0xB0;            // Primitive->Rotation 176 (CFrame starts here)
    inline constexpr uintptr_t Transparency = 0x120;     // 288
    inline constexpr uintptr_t Anchored = 0x1B6;         // flags byte, bit AnchoredMask
    inline constexpr uintptr_t PrimitiveFlags = 0x1B6;   // Primitive->Flags 438
    inline constexpr uintptr_t AnchoredMask = 0x2;
    inline constexpr uintptr_t CanCollideMask = 0x8;
    inline constexpr uintptr_t CanTouchMask = 0x10;

    inline constexpr uintptr_t CameraPos = 0xEC;         // Camera->Position 236
    inline constexpr uintptr_t CameraRotation = 0xC8;    // 200
    inline constexpr uintptr_t CameraSubject = 0xB8;     // 184
    inline constexpr uintptr_t CameraType = 0x128;       // 296
    inline constexpr uintptr_t FOV = 0x130;              // 304
    inline constexpr uintptr_t ViewportSize = 0x2CC;     // 716
    inline constexpr uintptr_t WorkspaceCamera = 0x4A8;  // Workspace->CurrentCamera 1192

    inline constexpr uintptr_t Workspace = 0x150;        // DataModel->Workspace 336
    inline constexpr uintptr_t GameLoaded = 0x5D0;       // 1488
    inline constexpr uintptr_t PlaceId = 0x188;          // 392
    inline constexpr uintptr_t DataModelToRenderView1 = 0x1C0; // 448
    inline constexpr uintptr_t DataModelToRenderView2 = 0x8;
    inline constexpr uintptr_t DataModelToRenderView3 = 0x28;

    inline constexpr uintptr_t viewmatrix = ViewMatrix;  // alias for old base compat
    // Lighting (service under DataModel)
    inline constexpr uintptr_t FogColorL = 0xE4;         // 228
    inline constexpr uintptr_t AmbientL = 0xC0;          // 192
    inline constexpr uintptr_t OutdoorAmbientL = 0xF0;   // 240
    inline constexpr uintptr_t FogStartL = 0x120;        // 288
    inline constexpr uintptr_t FogEndL = 0x11C;          // 284
    inline constexpr uintptr_t BrightnessL = 0x108;      // 264
    inline constexpr uintptr_t ClockTimeL = 0xB8;        // 184
    // Camera zoom (third person force)
    inline constexpr uintptr_t CamMinZoom = 0x35C;       // Player MinZoom 860
    inline constexpr uintptr_t CamMaxZoom = 0x358;       // Player MaxZoom 856
    inline constexpr uintptr_t StringLength = 0x10;
    inline constexpr uintptr_t Adornee = 0xE0;            // 224
    inline constexpr uintptr_t Value = 0xA8;             // 168
}

namespace OffsetAutoUpdater {
    // Minimal WinHTTP GET, no deps. Returns body as std::string, empty on fail.
    inline std::string HttpGet(const std::wstring& host, const std::wstring& path) {
        std::string out;
        HINTERNET hSession = WinHttpOpen(L"4080External/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!hSession) return out;
        HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!hConnect) { WinHttpCloseHandle(hSession); return out; }
        HINTERNET hReq = WinHttpOpenRequest(hConnect, L"GET", path.c_str(), nullptr,
            WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (!hReq) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return out; }
        if (!WinHttpSendRequest(hReq, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
            WinHttpCloseHandle(hReq); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return out;
        }
        if (!WinHttpReceiveResponse(hReq, nullptr)) {
            WinHttpCloseHandle(hReq); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return out;
        }
        char buf[4096]; DWORD read = 0;
        while (WinHttpReadData(hReq, buf, sizeof(buf), &read) && read > 0)
            out.append(buf, buf + read);
        WinHttpCloseHandle(hReq); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession);
        return out;
    }

    // Tiny JSON int extractor: finds "Key": 1234 pattern. No JSON lib needed.
    inline bool ExtractInt(const std::string& json, const std::string& section,
        const std::string& key, uintptr_t& outVal) {
        auto sPos = json.find("\"" + section + "\"");
        if (sPos == std::string::npos) return false;
        auto kPos = json.find("\"" + key + "\"", sPos);
        if (kPos == std::string::npos || kPos - sPos > 4000) return false;
        auto cPos = json.find(':', kPos);
        if (cPos == std::string::npos) return false;
        try { outVal = static_cast<uintptr_t>(std::stoul(json.substr(cPos + 1))); return true; }
        catch (...) { return false; }
    }

    struct LiveOffsets {
        uintptr_t fakeDM = offsets::FakeDataModelPointer;
        uintptr_t fakeDMToReal = offsets::FakeDataModelToDataModel;
        uintptr_t visualEngine = offsets::VisualEnginePointer;
        uintptr_t viewMatrix = offsets::ViewMatrix;
        uintptr_t health = offsets::Health;
        uintptr_t maxHealth = offsets::MaxHealth;
        uintptr_t walkSpeed = offsets::WalkSpeed;
        uintptr_t walkSpeedCheck = offsets::WalkSpeedCheck;
        uintptr_t jumpPower = offsets::JumpPower;
        uintptr_t primitive = offsets::Primitive;
        uintptr_t position = offsets::Position;
        uintptr_t localPlayer = offsets::LocalPlayer;
        uintptr_t modelInstance = offsets::ModelInstance;
        std::string version;
    };

    // Call once at startup. Falls back silently to compiled-in values on any failure.
    inline LiveOffsets Fetch() {
        LiveOffsets live;
        std::string json = HttpGet(L"offsets.imtheo.lol", L"/offsets.json");
        if (json.empty()) return live;
        auto vp = json.find("\"Roblox Version\"");
        if (vp != std::string::npos) {
            auto q1 = json.find('"', vp + 18), q2 = json.find('"', q1 + 1);
            if (q1 != std::string::npos && q2 != std::string::npos)
                live.version = json.substr(q1 + 1, q2 - q1 - 1);
        }
        uintptr_t v = 0;
        if (ExtractInt(json, "FakeDataModel", "Pointer", v)) live.fakeDM = v;
        if (ExtractInt(json, "FakeDataModel", "RealDataModel", v)) live.fakeDMToReal = v;
        if (ExtractInt(json, "VisualEngine", "Pointer", v)) live.visualEngine = v;
        if (ExtractInt(json, "VisualEngine", "ViewMatrix", v)) live.viewMatrix = v;
        if (ExtractInt(json, "Humanoid", "Health", v)) live.health = v;
        if (ExtractInt(json, "Humanoid", "MaxHealth", v)) live.maxHealth = v;
        if (ExtractInt(json, "Humanoid", "Walkspeed", v)) live.walkSpeed = v;
        if (ExtractInt(json, "Humanoid", "WalkspeedCheck", v)) live.walkSpeedCheck = v;
        if (ExtractInt(json, "Humanoid", "JumpPower", v)) live.jumpPower = v;
        if (ExtractInt(json, "BasePart", "Primitive", v)) live.primitive = v;
        if (ExtractInt(json, "Primitive", "Position", v)) live.position = v;
        if (ExtractInt(json, "Player", "LocalPlayer", v)) live.localPlayer = v;
        if (ExtractInt(json, "Player", "ModelInstance", v)) live.modelInstance = v;
        return live;
    }
}
