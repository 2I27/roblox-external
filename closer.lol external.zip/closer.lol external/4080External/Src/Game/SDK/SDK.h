#pragma once
// language: C++, file: 4080External/Src/Game/SDK/SDK.h, runtime: Windows 11 x64
// *Health/MaxHealth/WalkSpeed are floats in current builds — reading as int returns garbage*
#include "../Offsets/Offsets.h"
#include "../../Memory/Communication.h"
#include <string>
#include <vector>
#include <cmath>

namespace RBX {
    struct Vec2 { float X{0}, Y{0}; };
    struct Vec3 { float X{0}, Y{0}, Z{0}; };
    struct Vec4 { float X{0}, Y{0}, Z{0}, W{0}; };
    struct Mat4 { float data[16]{}; };
    struct CFrame {
        float data[12]{};
        Vec3 Right() const { return {data[0], data[3], data[6]}; }
        Vec3 Up() const { return {data[1], data[4], data[7]}; }
        Vec3 Look() const { return {data[2], data[5], data[8]}; }
        Vec3 Pos() const { return {data[9], data[10], data[11]}; }
    };

    // Live offsets resolved at startup (auto-update fills these, fallback = compiled-in).
    struct Live {
        inline static uintptr_t oHealth = offsets::Health;
        inline static uintptr_t oMaxHealth = offsets::MaxHealth;
        inline static uintptr_t oWalkSpeed = offsets::WalkSpeed;
        inline static uintptr_t oWalkSpeedCheck = offsets::WalkSpeedCheck;
        inline static uintptr_t oJumpPower = offsets::JumpPower;
        inline static uintptr_t oLocalPlayer = offsets::LocalPlayer;
        inline static uintptr_t oModelInstance = offsets::ModelInstance;
        inline static uintptr_t oViewMatrix = offsets::ViewMatrix;
    };

    class RbxInstance {
    public:
        uintptr_t Addr = 0;
        RbxInstance(uintptr_t a = 0) : Addr(a) {}
        explicit operator bool() const { return Addr != 0; }

        // Name (live-verified): string object at (ptr @ +0x70) + 8. Class: object at (ptr @ desc+8).
        std::string GetName() {
            if (!Addr) return "";
            uintptr_t p = Coms->ReadMemory<uintptr_t>(Addr + offsets::NameContainer);
            if (p > 0x10000) {
                std::string s = Coms->ReadGameString(p + 8);
                if (!s.empty()) return s;
                s = Coms->ReadGameString(p);
                if (!s.empty()) return s;
            }
            std::string s = Coms->ReadGameString(Addr + offsets::NameContainer + 8);
            if (!s.empty()) return s;
            return Coms->ReadGameString(Addr + offsets::NameContainer);
        }
        std::string GetClass() {
            if (!Addr) return "";
            uintptr_t desc = Coms->ReadMemory<uintptr_t>(Addr + offsets::ClassDescriptor);
            if (desc > 0x10000) {
                std::string s = Coms->ReadGameString(desc + offsets::ClassDescriptorToClassName);
                if (!s.empty()) return s;
                uintptr_t np = Coms->ReadMemory<uintptr_t>(desc + offsets::ClassDescriptorToClassName);
                if (np > 0x10000) { s = Coms->ReadGameString(np); if (!s.empty()) return s; }
            }
            return "";
        }
        RbxInstance GetParent() { return RbxInstance(Coms->ReadMemory<uintptr_t>(Addr + offsets::Parent)); }

        std::vector<RbxInstance> GetChildList() {
            std::vector<RbxInstance> out;
            if (!Addr) return out;
            uintptr_t arr = Coms->ReadMemory<uintptr_t>(Addr + offsets::Children);
            if (!arr) return out;
            uintptr_t start = Coms->ReadMemory<uintptr_t>(arr);
            uintptr_t end = Coms->ReadMemory<uintptr_t>(arr + offsets::ChildrenEnd);
            if (!start || !end || end < start || (end - start) > 0x10000) return out;
            for (uintptr_t p = start; p < end; p += 0x10) {
                uintptr_t c = Coms->ReadMemory<uintptr_t>(p);
                if (c) out.emplace_back(c);
            }
            return out;
        }
        RbxInstance FindChild(const std::string& n) {
            for (auto& c : GetChildList()) if (c.GetName() == n) return c;
            return RbxInstance(0);
        }
        RbxInstance FindChildByClass(const std::string& cl) {
            for (auto& c : GetChildList()) {
                // class first, name as backup (services share name==class; names read more reliably)
                std::string got = c.GetClass();
                if (got == cl) return c;
                if (got.empty() && c.GetName() == cl) return c;
            }
            return RbxInstance(0);
        }
        // Fallback: match by name OR class (survives when one reader breaks).
        RbxInstance FindChildAny(const std::string& n) {
            for (auto& c : GetChildList()) {
                if (c.GetName() == n || c.GetClass() == n) return c;
            }
            return RbxInstance(0);
        }
        // All descendant BaseParts (for noclip/chams). Depth-capped.
        void CollectParts(std::vector<RbxInstance>& out, int depth = 0) {
            if (depth > 3) return;
            for (auto& c : GetChildList()) {
                uintptr_t prim = Coms->ReadMemory<uintptr_t>(c.Addr + offsets::Primitive);
                if (prim) out.push_back(c);
                c.CollectParts(out, depth + 1);
                if (out.size() > 64) return;
            }
        }
        // Health: try float, then int. Returns -1 if unreadable.
        float ReadHealth(uintptr_t humanoid) {
            float h = Coms->ReadMemory<float>(humanoid + Live::oHealth);
            if (h > 0 && h < 100000) return h;
            int hi = Coms->ReadMemory<int>(humanoid + Live::oHealth);
            if (hi > 0 && hi < 100000) return (float)hi;
            return -1.0f;
        }
        float ReadMaxHealth(uintptr_t humanoid) {
            float h = Coms->ReadMemory<float>(humanoid + Live::oMaxHealth);
            if (h > 0 && h < 100000) return h;
            return 100.0f;
        }
        // Knocked/dead approx: state id check + health. DaHood uses knocked states.
        bool IsKnocked(uintptr_t humanoid) {
            int st = Coms->ReadMemory<int>(humanoid + offsets::HumanoidState);
            if (st == 0) st = Coms->ReadMemory<int>(humanoid + offsets::HumanoidStateId);
            // seated/fallen/physics states commonly indicate knocked
            return (st == 3 || st == 5 || st == 6);
        }
        // Hit part resolver: 0 Head 1 Torso/HRP 2 LArm 3 RArm 4 LLeg 5 RLeg 6 Closest-to-crosshair(fallback head)
        RbxInstance ResolveHitPart(RbxInstance ch, int idx, uintptr_t rootAddr) {
            auto byNames = [&](std::initializer_list<const char*> nms) -> RbxInstance {
                for (auto n : nms) { auto p = ch.FindChild(n); if (p) return p; }
                return RbxInstance(0);
            };
            bool r6 = ch.FindChild("Torso").Addr != 0;
            RbxInstance out(0);
            switch (idx) {
                case 0: out = byNames({"Head"}); break;
                case 1: out = r6 ? byNames({"Torso"}) : byNames({"UpperTorso","LowerTorso","Torso"}); break;
                case 2: out = r6 ? byNames({"Left Arm"}) : byNames({"LeftHand","LeftUpperArm","LeftLowerArm"}); break;
                case 3: out = r6 ? byNames({"Right Arm"}) : byNames({"RightHand","RightUpperArm","RightLowerArm"}); break;
                case 4: out = r6 ? byNames({"Left Leg"}) : byNames({"LeftFoot","LeftUpperLeg","LeftLowerLeg"}); break;
                case 5: out = r6 ? byNames({"Right Leg"}) : byNames({"RightFoot","RightUpperLeg","RightLowerLeg"}); break;
                default: out = byNames({"Head"}); break;
            }
            if (!out && rootAddr) out = RbxInstance(rootAddr);
            return out;
        }
        Vec3 ReadVelocity(uintptr_t partAddr) {
            uintptr_t prim = Coms->ReadMemory<uintptr_t>(partAddr + offsets::Primitive);
            if (!prim) return {};
            return Coms->ReadMemory<Vec3>(prim + offsets::Velocity);
        }
        std::string ReadDisplayName(uintptr_t playerAddr) {
            // Player DisplayName 296 (0x128)
            uintptr_t dp = playerAddr + 0x128;
            std::string s = Coms->ReadGameString(dp);
            if (!s.empty()) return s;
            return RbxInstance(playerAddr).GetName();
        }
        std::string ReadEquippedTool(RbxInstance ch) {
            for (auto& c : ch.GetChildList()) {
                std::string cl = c.GetClass();
                if (cl == "Tool" || cl == "HopperBin") return c.GetName();
                // class-flake fallback: tools hold a Handle part
                if (cl.empty() && c.FindChild("Handle")) return c.GetName();
            }
            return "";
        }

        uintptr_t Prim() { return Coms->ReadMemory<uintptr_t>(Addr + offsets::Primitive); }
        Vec3 GetPos() {
            uintptr_t prim = Coms->ReadMemory<uintptr_t>(Addr + offsets::Primitive);
            if (!prim) return {};
            return Coms->ReadMemory<Vec3>(prim + offsets::Position);
        }
        CFrame GetCFrame() {
            uintptr_t prim = Coms->ReadMemory<uintptr_t>(Addr + offsets::Primitive);
            if (!prim) return {};
            return Coms->ReadMemory<CFrame>(prim + offsets::CFrame);
        }
        RbxInstance GetModelRef() { return RbxInstance(Coms->ReadMemory<uintptr_t>(Addr + Live::oModelInstance)); }
        float DistTo(const Vec3& t) {
            Vec3 c = GetPos();
            float dx=c.X-t.X, dy=c.Y-t.Y, dz=c.Z-t.Z;
            return sqrtf(dx*dx+dy*dy+dz*dz);
        }
    };

    class RenderEngine : public RbxInstance {
    public:
        RenderEngine(uintptr_t a = 0) : RbxInstance(a) {}
        Mat4 GetViewMat() { return Coms->ReadMemory<Mat4>(Addr + Live::oViewMatrix); }
    };

    inline void SetWalkSpeed(uintptr_t humanoid, float v) {
        Coms->WriteMemory<float>(humanoid + Live::oWalkSpeed, v);
        Coms->WriteMemory<float>(humanoid + Live::oWalkSpeedCheck, v);
    }
    inline void SetJumpPower(uintptr_t humanoid, float v) {
        Coms->WriteMemory<float>(humanoid + Live::oJumpPower, v);
    }
    // Noclip: clear CanCollide bit on Primitive flags (438), restore by setting it.
    inline void SetPartCollide(uintptr_t partAddr, bool collide) {
        uintptr_t prim = Coms->ReadMemory<uintptr_t>(partAddr + offsets::Primitive);
        if (!prim) return;
        uint8_t flags = Coms->ReadMemory<uint8_t>(prim + offsets::PrimitiveFlags);
        if (collide) flags |= (uint8_t)offsets::CanCollideMask;
        else flags &= (uint8_t)~offsets::CanCollideMask;
        Coms->WriteMemory<uint8_t>(prim + offsets::PrimitiveFlags, flags);
    }
    // Camera-angle aim (external "silent"): pitch/yaw from camera pos to target.
    inline void AimCameraAt(uintptr_t cameraAddr, const Vec3& camPos, const Vec3& target, float smooth) {
        float dx = target.X - camPos.X, dy = target.Y - camPos.Y, dz = target.Z - camPos.Z;
        float yaw = atan2f(-dx, -dz);
        float hyp = sqrtf(dx*dx + dz*dz);
        float pitch = atan2f(dy, hyp);
        // Rotation layout: write yaw/pitch pair; smoothed toward goal.
        Vec2 cur = Coms->ReadMemory<Vec2>(cameraAddr + offsets::CameraRotation);
        Vec2 goal{ pitch, yaw };
        Vec2 out{ cur.X + (goal.X - cur.X) / smooth, cur.Y + (goal.Y - cur.Y) / smooth };
        Coms->WriteMemory<Vec2>(cameraAddr + offsets::CameraRotation, out);
    }
}
