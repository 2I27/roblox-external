#pragma once
// language: C++, file: 4080External/Src/Game/W2S/W2S.h
#include "../SDK/SDK.h"
namespace W2S {
    inline RBX::Vec2 WorldToScreen(const RBX::Vec3& w, const RBX::Mat4& m, float sw, float sh) {
        RBX::Vec4 q;
        q.X = w.X*m.data[0]+w.Y*m.data[1]+w.Z*m.data[2]+m.data[3];
        q.Y = w.X*m.data[4]+w.Y*m.data[5]+w.Z*m.data[6]+m.data[7];
        q.Z = w.X*m.data[8]+w.Y*m.data[9]+w.Z*m.data[10]+m.data[11];
        q.W = w.X*m.data[12]+w.Y*m.data[13]+w.Z*m.data[14]+m.data[15];
        RBX::Vec2 s{};
        if (q.W < 0.1f) return s;
        float nx = q.X/q.W, ny = q.Y/q.W;
        s.X = (sw/2.0f*nx)+(sw/2.0f);
        s.Y = -(sh/2.0f*ny)+(sh/2.0f);
        return s;
    }
}
