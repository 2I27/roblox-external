#include "Memory/Communication.h"
#include "Game/Offsets/Offsets.h"
#include "Game/SDK/SDK.h"
#include "Render/Render.h"
#include "Core/Globals/Globals.h"
#include "Core/Cache/Cache.h"
#include "Core/Features/Visuals/Visuals.h"
#include "Core/Features/Aimbot/Aimbot.h"
#include "Core/Features/Silent/SilentAim.h"
#include "Core/Features/Misc/Misc.h"
#include "Core/Features/World/WorldFX.h"
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <windows.h>
#include <atomic>

// language: C++, file: closer.lol/Src/Main.cpp, runtime: Windows 11 x64
// *Run as admin if reads fail — Roblox is a protected process; handle needs SeDebugPrivilege*

std::atomic<bool> running(true);

void CharThread() {
    while (running) {
        CharFX::Run();
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

int main(int argc, char** argv) {
    bool selftest = false;
    std::string argKey = "";
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--selftest") selftest = true;
        if (a.rfind("--key=", 0) == 0) argKey = a.substr(6);
    }
    std::cout << "  ___ ___ ___ ___ ___ ___\n |  _|  _| . | . | -_|  _|\n |___|_| |___|___|___|_|  closer.lol\n\n";
    OverlayWindow overlay;
    if (!overlay.Initialize()) { std::cout << "[!] Overlay failed\n"; return -1; }
    // GUI key gate (console prompt retired): closer.key remembers you.
    bool guiAuthed = selftest;
    if (!argKey.empty()) guiAuthed = (argKey == "key");
    if (!guiAuthed && !selftest) {
        std::cout << "[*] Waiting for key in overlay window...\n";
        while (!guiAuthed) {
            overlay.BeginFrame();
            guiAuthed = CloserUI::RenderKeyGate();
            overlay.EndFrame();
            if (!overlay.GetWindowHandle()) return -1;
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
        }
        system("cls");
    } else if (!selftest) {
        std::cout << "[+] Key accepted via args\n";
    }
    if (selftest) {
        std::cout << "[SELFTEST] auto mode: ESP+aim+silent on, 20s, results to closer.log\n";
        Vars::ESP::enabled = true; Vars::ESP::boxes = true; Vars::ESP::names = true;
        Vars::ESP::healthBar = true; Vars::ESP::distanceText = true; Vars::ESP::skeleton = true;
        Vars::Aimbot::enabled = true; Aimbot::forceActive = true; Vars::Aimbot::smoothing = 30.0f;
        Vars::Aimbot::fovRadius = 2000.0f; // selftest: prove selection+mouse path regardless of aim
        Vars::Silent::enabled = true; Vars::Silent::autoFire = true; Vars::Silent::showSnapline = true;
        Vars::Silent::magicBullet = true; // wide FOV guarantees a target if any project on screen
        SetCursorPos(GetSystemMetrics(SM_CXSCREEN) / 2, GetSystemMetrics(SM_CYSCREEN) / 2);
        Vars::Misc::playerList = false;
    }
    std::cout << "[+] Welcome to closer.lol\n[*] Fetching live offsets...\n";
    if (Vars::Style::hideConsole) ShowWindow(GetConsoleWindow(), SW_HIDE);
    auto live = OffsetAutoUpdater::Fetch();
    RBX::Live::oHealth = live.health; RBX::Live::oMaxHealth = live.maxHealth;
    RBX::Live::oWalkSpeed = live.walkSpeed; RBX::Live::oWalkSpeedCheck = live.walkSpeedCheck;
    RBX::Live::oJumpPower = live.jumpPower; RBX::Live::oLocalPlayer = live.localPlayer;
    RBX::Live::oModelInstance = live.modelInstance; RBX::Live::oViewMatrix = live.viewMatrix;
    Globals::offsetVersion = live.version.empty() ? "compiled-in fallback" : live.version;
    std::cout << "[+] Offsets: " << Globals::offsetVersion << "\n";

    std::cout << "[*] Searching for RobloxPlayerBeta.exe (run exe as ADMIN if this loops)...\n";
    while (!Coms->Connect(L"RobloxPlayerBeta.exe")) std::this_thread::sleep_for(std::chrono::seconds(2));
    system("cls");
    auto base = Coms->GetBase();
    std::cout << "[+] PID: " << Coms->GetPID() << " Base: 0x" << std::hex << base << std::dec << "\n";

    std::this_thread::sleep_for(std::chrono::seconds(2));
    // Wait for a live game session: the DataModel slot is empty at homepage/loading.
    // Old behavior exited here — launching before joining a game looked like "nothing works".
    uintptr_t fakeDM = 0, dataModelPtr = 0, visualEngine = 0;
    std::cout << "[*] Waiting for game session (join a game)...\n";
    for (int tries = 0; tries < 120 && (!dataModelPtr || !visualEngine); tries++) {
        if (!Coms->IsConnected()) {
            std::cout << "[!] Lost process, reconnecting...\n";
            while (!Coms->Connect(L"RobloxPlayerBeta.exe")) std::this_thread::sleep_for(std::chrono::seconds(2));
            base = Coms->GetBase();
        }
        fakeDM = Coms->ReadMemory<uintptr_t>(base + live.fakeDM);
        dataModelPtr = fakeDM ? Coms->ReadMemory<uintptr_t>(fakeDM + live.fakeDMToReal) : 0;
        visualEngine = Coms->ReadMemory<uintptr_t>(base + live.visualEngine);
        if (!dataModelPtr || !visualEngine) {
            if (tries % 10 == 0) std::cout << "[.] still waiting... (join a game)\n";
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
    if (!dataModelPtr || !visualEngine) {
        std::cout << "[!] No session after 120s — join a game first, then run again.\n";
        system("pause"); return -1;
    }
    // stealth: console did its job (key + waiting text), now vanish. Diag lives in closer.log + overlay.
    if (Vars::Style::hideConsole) ShowWindow(GetConsoleWindow(), SW_HIDE);
    Globals::dataModel = RBX::RbxInstance(dataModelPtr);
    Globals::renderEngine = RBX::RenderEngine(visualEngine);
    Globals::workspace = Globals::dataModel.FindChildByClass("Workspace");
    if (!Globals::workspace) Globals::workspace = Globals::dataModel.FindChildAny("Workspace");
    Globals::players = Globals::dataModel.FindChildByClass("Players");
    if (!Globals::players) Globals::players = Globals::dataModel.FindChildAny("Players");
    Globals::camera = Globals::workspace.FindChildByClass("Camera");
    if (!Globals::camera) Globals::camera = Globals::workspace.FindChildAny("Camera");
    if (!Globals::camera && Globals::workspace.Addr) {
        uintptr_t camPtr = Coms->ReadMemory<uintptr_t>(Globals::workspace.Addr + offsets::WorkspaceCamera);
        if (camPtr > 0x10000) Globals::camera = RBX::RbxInstance(camPtr);
    }
    Globals::localPlayer = RBX::RbxInstance(Coms->ReadMemory<uintptr_t>(Globals::players.Addr + RBX::Live::oLocalPlayer));

    std::cout << "[+] DataModel: 0x" << std::hex << dataModelPtr
              << "\n[+] VisualEngine: 0x" << visualEngine
              << "\n[+] Workspace: 0x" << Globals::workspace.Addr << " (" << Globals::workspace.GetClass() << ")"
              << "\n[+] Players: 0x" << Globals::players.Addr << " (" << Globals::players.GetClass() << ")"
              << "\n[+] Camera: 0x" << Globals::camera.Addr
              << "\n[+] LocalPlayer: 0x" << Globals::localPlayer.Addr << " (" << Globals::localPlayer.GetName() << ")" << std::dec << "\n";
    PlayerCache::UpdatePlayers();
    std::cout << "[diag] scanned=" << PlayerCache::diagScanned << " noChar=" << PlayerCache::diagNoChar
              << " noHum=" << PlayerCache::diagNoHum << " dead=" << PlayerCache::diagDead
              << " valid=" << PlayerCache::players.size() << "\n";
    { std::ofstream log("closer.log", std::ios::app);
      log << "closer.lol " << Globals::offsetVersion << " pid=" << Coms->GetPID()
          << " ws=0x" << std::hex << Globals::workspace.Addr << " pl=0x" << Globals::players.Addr
          << " cam=0x" << Globals::camera.Addr << " local=0x" << Globals::localPlayer.Addr << std::dec
          << " scanned=" << PlayerCache::diagScanned << " valid=" << PlayerCache::players.size()
          << " fail=" << PlayerCache::diagFirstFail << "\n"; }
    if (PlayerCache::players.empty())
        std::cout << "[!] WARN: 0 players cached. Join a game with others, or offsets shifted — paste this block to me.\n";
    std::cout << "[*] INSERT = menu, END = exit\n";

    std::thread charThread(CharThread);

    int frame = 0;
    // menu toggle: latched rising-edge + debounce. Old code sampled "& 1" once per
    // frame and dropped presses whenever a frame stalled — the "menu won't open" bug.
    int lastIns = 0, lastHome = 0;
    DWORD lastToggle = 0;
    auto testStart = std::chrono::steady_clock::now();
    int lastLoggedSec = -1;
    while (Coms->IsConnected()) {
        if (!selftest && !FindWindowW(NULL, L"Roblox")) break;
        {
            int ins = (GetAsyncKeyState(VK_INSERT) & 0x8000) ? 1 : 0;
            int home = (GetAsyncKeyState(VK_HOME) & 0x8000) ? 1 : 0;
            DWORD nowT = GetTickCount();
            if (((ins && !lastIns) || (home && !lastHome)) && nowT - lastToggle > 250) {
                Vars::menuOpen = !Vars::menuOpen;
                lastToggle = nowT;
                // opened menu must sit above the game: reassert topmost or it "won't open" visually
                if (Vars::menuOpen && overlay.GetWindowHandle())
                    SetWindowPos(overlay.GetWindowHandle(), HWND_TOPMOST, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
            }
            lastIns = ins; lastHome = home;
        }
        if (GetAsyncKeyState(VK_END) & 1) break;
        // panic: everything off + menu gone, one key
        if (Vars::Misc::panicKey > 0 && (GetAsyncKeyState(Vars::Misc::panicKey) & 1)) {
            Vars::Aimbot::enabled = false; Vars::Silent::enabled = false; Vars::ESP::enabled = false;
            Vars::Character::speedEnabled = false; Vars::Character::flyEnabled = false;
            Vars::Character::noclip = false; Vars::Character::floatEnabled = false;
            Vars::Misc::rapidFire = false; Vars::Misc::triggerbot = false; Vars::Aimbot::triggerbot = false;
            Vars::Camera::fovChanger = false; Vars::World::customFog = false;
            Vars::World::glow = false; Vars::World::fullbright = false; Vars::World::noFog = false;
            Vars::menuOpen = false;
        }
        if (frame % 3 == 0) PlayerCache::UpdatePlayers();
        if (frame % 60 == 0) WorldFX::Run();
        frame++;
        if (selftest) {
            int sec = (int)std::chrono::duration_cast<std::chrono::seconds>(
                std::chrono::steady_clock::now() - testStart).count();
            if (sec != lastLoggedSec) {
                lastLoggedSec = sec;
                std::ofstream log("closer.log", std::ios::app);
                log << "[SELFTEST t=" << sec << "] valid=" << PlayerCache::players.size()
                    << " boxes=" << Visuals::lastBoxes
                    << " aimLock=0x" << std::hex << Aimbot::locked << std::dec
                    << " aimTarget=0x" << std::hex << Globals::aimTargetAddr << std::dec
                    << " silent=" << Globals::silentHasTarget
                    << " scan=" << PlayerCache::diagScanned
                    << " noChar=" << PlayerCache::diagNoChar << " noHum=" << PlayerCache::diagNoHum
                    << " dead=" << PlayerCache::diagDead << " fail=" << PlayerCache::diagFirstFail << "\n";
                // per-target pick debug: why does FOV selection skip everyone?
                {
                    POINT dbgMp; GetCursorPos(&dbgMp);
                    float dbgSw = (float)GetSystemMetrics(SM_CXSCREEN), dbgSh = (float)GetSystemMetrics(SM_CYSCREEN);
                    auto dbgVm = Globals::renderEngine.GetViewMat();
                    int shown = 0;
                    for (auto& p : PlayerCache::players) {
                        if (shown >= 3) break;
                        if (!p.isValid) continue;
                        shown++;
                        RBX::Vec3 tp = Aimbot::TargetPos(p);
                        RBX::Vec2 ssp = W2S::WorldToScreen(tp, dbgVm, dbgSw, dbgSh);
                        float dx = ssp.X - dbgMp.x, dy = ssp.Y - dbgMp.y;
                        log << "[SELFTEST-PICK] " << p.name << " hp=" << p.health << " dist=" << p.distance
                            << " team=0x" << std::hex << p.teamAddr << std::dec
                            << " w3=(" << tp.X << "," << tp.Y << "," << tp.Z << ")"
                            << " scr=(" << ssp.X << "," << ssp.Y << ") cursor=(" << dbgMp.x << "," << dbgMp.y << ")"
                            << " d2=" << sqrtf(dx*dx+dy*dy) << "\n";
                    }
                }
            }
            if (sec >= 20) break;
        }

        float sw = (float)GetSystemMetrics(SM_CXSCREEN), sh = (float)GetSystemMetrics(SM_CYSCREEN);
        ImGuiStyle& st = ImGui::GetStyle();
        st.Colors[ImGuiCol_SliderGrab] = ImVec4(Vars::Style::accent[0], Vars::Style::accent[1], Vars::Style::accent[2], 1.0f);
        st.Colors[ImGuiCol_CheckMark] = ImVec4(Vars::Style::accent[0], Vars::Style::accent[1], Vars::Style::accent[2], 1.0f);
        overlay.BeginFrame();
        overlay.RenderMenu();
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        ImU32 acc = IM_COL32((int)(Vars::Style::accent[0]*255), (int)(Vars::Style::accent[1]*255), (int)(Vars::Style::accent[2]*255), 255);

        // Only paint the game while Roblox owns the screen — no more overlaying your browser.
        // Window resolved by PID (titles vary); if unresolvable, draw rather than hide everything.
        HWND fgGame = OverlayWindow::FindGameByPid(Coms->GetPID());
        HWND fg = GetForegroundWindow();
        bool gameFront = selftest ? true : (fgGame ? (fg == fgGame) : true);
        if (!gameFront) { overlay.EndFrame(); continue; }

        std::string wm = "closer.lol | " + Globals::offsetVersion + " | players: " + std::to_string(PlayerCache::players.size());
        {
            // fps EMA for the watermark
            static DWORD lastF = 0; static float fps = 60.0f;
            DWORD nowF = GetTickCount();
            if (lastF) { float dt = (float)(nowF - lastF); if (dt > 0) fps = fps * 0.9f + (1000.0f / dt) * 0.1f; }
            lastF = nowF;
            char fb[16]; snprintf(fb, sizeof(fb), " %d fps", (int)(fps + 0.5f));
            wm += fb;
        }
        ImVec2 ts = ImGui::CalcTextSize(wm.c_str());
        ImVec2 wp(sw - ts.x - 10, 10);
        dl->AddText(ImVec2(wp.x-1,wp.y), IM_COL32(0,0,0,255), wm.c_str());
        dl->AddText(ImVec2(wp.x+1,wp.y), IM_COL32(0,0,0,255), wm.c_str());
        dl->AddText(wp, acc, wm.c_str());

        // attach status: proves the external is connected, not just drawing.
        {
            std::string st1 = "PID " + std::to_string(Coms->GetPID()) + " | base 0x" + [&]{ char b[32]; snprintf(b,32,"%llX",(unsigned long long)Coms->GetBase()); return std::string(b); }();
            std::string st2 = "players " + std::to_string(PlayerCache::players.size()) + " (scan " + std::to_string(PlayerCache::diagScanned) + ") | local " + Globals::localPlayer.GetName();
            dl->AddText(ImVec2(12, 10), IM_COL32(0,0,0,255), st1.c_str());
            dl->AddText(ImVec2(12, 26), IM_COL32(0,0,0,255), st2.c_str());
            dl->AddText(ImVec2(11, 9), IM_COL32(0,255,150,255), st1.c_str());
            dl->AddText(ImVec2(11, 25), acc, st2.c_str());
            {
                char dg[128]; snprintf(dg, sizeof(dg), "scan %d noChar %d noHum %d dead %d",
                    PlayerCache::diagScanned, PlayerCache::diagNoChar, PlayerCache::diagNoHum, PlayerCache::diagDead);
                dl->AddText(ImVec2(11, 41), IM_COL32(255,220,120,255), dg);
            }
            if (!PlayerCache::diagFirstFail.empty())
                dl->AddText(ImVec2(11, 57), IM_COL32(255,150,80,255), PlayerCache::diagFirstFail.c_str());
            if (PlayerCache::players.empty()) {
                const char* hint = "no targets: join a server WITH other players, then enable ESP";
                dl->AddText(ImVec2(11, 73), IM_COL32(255,120,120,255), hint);
            }
        }

        if (Vars::Misc::crosshair) {
            dl->AddLine(ImVec2(sw/2-10, sh/2), ImVec2(sw/2+10, sh/2), acc, 1.5f);
            dl->AddLine(ImVec2(sw/2, sh/2-10), ImVec2(sw/2, sh/2+10), acc, 1.5f);
        }
        if (Vars::Aimbot::enabled && Vars::Aimbot::showFOV) {
            POINT p; GetCursorPos(&p);
            int seg = 24 + (int)(Vars::Aimbot::fovSmooth * 8.0f);
            ImVec2 c((float)p.x, (float)p.y);
            if (Vars::Aimbot::fillFOV) dl->AddCircleFilled(c, Vars::Aimbot::fovRadius, IM_COL32(255,255,255,25), seg);
            dl->AddCircle(c, Vars::Aimbot::fovRadius, IM_COL32(0,0,0,255), seg, 2.0f);
            dl->AddCircle(c, Vars::Aimbot::fovRadius, acc, seg, 1.0f);
        }
        auto vm = Globals::renderEngine.GetViewMat();
        Aimbot::Run(vm, sw, sh);
        SilentAim::Run(vm, sw, sh);
        SilentAim::DrawFOV(dl, acc);
        Misc::RunTriggerbot(vm, sw, sh);
        Misc::RunRapidFire();
        Visuals::RenderESP(dl, vm, sw, sh);
        Visuals::DrawSelfESP(dl, vm, sw, sh);
        Visuals::DrawRadar(dl, sw);
        // silent snapline: visible proof of silent target
        if (Vars::Silent::showSnapline && Globals::silentHasTarget) {
            POINT mp; GetCursorPos(&mp);
            dl->AddLine(ImVec2((float)mp.x, (float)mp.y),
                ImVec2(Globals::silentAimScreen.X, Globals::silentAimScreen.Y),
                IM_COL32(150, 120, 255, 220), 1.5f);
            dl->AddCircle(ImVec2(Globals::silentAimScreen.X, Globals::silentAimScreen.Y), 6.0f, acc, 12);
        }
        // hitmarker + kill counter
        {
            static bool wasMarked = false;
            bool marked = Vars::Misc::hitmarker && GetTickCount() < Globals::hitmarkerUntil;
            if (marked && !wasMarked && Vars::Misc::hitSound) Beep(880, 90);
            wasMarked = marked;
        }
        if (Vars::Misc::hitmarker && GetTickCount() < Globals::hitmarkerUntil) {
            float cx = sw/2, cy = sh/2;
            dl->AddLine(ImVec2(cx-10,cy-10), ImVec2(cx-4,cy-4), IM_COL32(255,60,60,255), 2.5f);
            dl->AddLine(ImVec2(cx+10,cy-10), ImVec2(cx+4,cy-4), IM_COL32(255,60,60,255), 2.5f);
            dl->AddLine(ImVec2(cx-10,cy+10), ImVec2(cx-4,cy+4), IM_COL32(255,60,60,255), 2.5f);
            dl->AddLine(ImVec2(cx+10,cy+10), ImVec2(cx+4,cy+4), IM_COL32(255,60,60,255), 2.5f);
        }
        if (Vars::Misc::kills > 0) {
            char kb[32]; snprintf(kb, sizeof(kb), "kills: %d", Vars::Misc::kills);
            dl->AddText(ImVec2(sw/2 - 30, sh/2 + 24), acc, kb);
        }
        // player list window
        if (Vars::Misc::playerList) {
            ImGui::SetNextWindowPos(ImVec2(sw - 250, 220), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(230, 260), ImGuiCond_FirstUseEver);
            ImGui::Begin("players", &Vars::Misc::playerList, ImGuiWindowFlags_NoCollapse);
            for (auto& p : PlayerCache::players) {
                if (!p.isValid) continue;
                char row[128]; snprintf(row, sizeof(row), "%s  %d/%d  %dm",
                    p.name.c_str(), (int)p.health, (int)p.maxHealth, (int)p.distance);
                ImGui::TextUnformatted(row);
            }
            ImGui::End();
        }
        overlay.EndFrame();
    }
    running = false;
    charThread.join();
    overlay.Cleanup();
    return 0;
}
