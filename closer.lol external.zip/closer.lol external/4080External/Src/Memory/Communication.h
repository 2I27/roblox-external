#pragma once
// language: C++, file: 4080External/Src/Memory/Communication.h, runtime: Windows 11 x64
// *OpenProcess(PROCESS_ALL_ACCESS) fails under protected processes — falls back gracefully, check IsConnected()*
#include <windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <string>
#include <memory>
#include "../Game/Offsets/Offsets.h"

class ProcessCommunicator final {
private:
    HANDLE hProcess{};
    uint32_t dwProcessId{};
    uintptr_t uModuleBase{};

public:
    ProcessCommunicator() = default;
    ~ProcessCommunicator() {
        if (hProcess && hProcess != INVALID_HANDLE_VALUE) CloseHandle(hProcess);
    }
    ProcessCommunicator(const ProcessCommunicator&) = delete;
    ProcessCommunicator& operator=(const ProcessCommunicator&) = delete;

    uint32_t FindProcessByName(const std::wstring& targetName) {
        uint32_t foundPid = 0;
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap == INVALID_HANDLE_VALUE) return foundPid;
        PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
        if (Process32FirstW(hSnap, &pe)) {
            do {
                if (_wcsicmp(targetName.c_str(), pe.szExeFile) == 0) { foundPid = pe.th32ProcessID; break; }
            } while (Process32NextW(hSnap, &pe));
        }
        CloseHandle(hSnap);
        return foundPid;
    }

    uintptr_t FindModuleBase(const std::wstring& targetModule) {
        uintptr_t foundBase = 0;
        if (!IsConnected()) return foundBase;
        DWORD pid = GetProcessId(hProcess);
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
        if (hSnap == INVALID_HANDLE_VALUE) return foundBase;
        MODULEENTRY32W me{}; me.dwSize = sizeof(me);
        if (Module32FirstW(hSnap, &me)) {
            do {
                if (_wcsicmp(targetModule.c_str(), me.szModule) == 0) {
                    foundBase = reinterpret_cast<uintptr_t>(me.modBaseAddr); break;
                }
            } while (Module32NextW(hSnap, &me));
        }
        CloseHandle(hSnap);
        return foundBase;
    }

    bool Connect(const std::wstring& targetName) {
        auto pid = FindProcessByName(targetName);
        if (pid == 0) return false;
        // NOTE: RobloxPlayerBeta.exe is 64-bit — build this cheat as x64 or reads will fail.
        HANDLE hProc = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION, FALSE, pid);
        if (!hProc || hProc == INVALID_HANDLE_VALUE) {
            hProc = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid);
            if (!hProc || hProc == INVALID_HANDLE_VALUE) return false;
        }
        hProcess = hProc;
        dwProcessId = pid;
        uModuleBase = FindModuleBase(targetName);
        return uModuleBase != 0;
    }

    void Disconnect() {
        if (hProcess && hProcess != INVALID_HANDLE_VALUE) { CloseHandle(hProcess); hProcess = nullptr; }
        dwProcessId = 0; uModuleBase = 0;
    }

    template <typename T>
    inline T ReadMemory(uintptr_t address) noexcept {
        T buffer{};
        if (!IsConnected() || address < 0x10000) [[unlikely]] return buffer;
        ReadProcessMemory(hProcess, reinterpret_cast<void*>(address), &buffer, sizeof(T), nullptr);
        return buffer;
    }

    template <typename T>
    inline bool WriteMemory(uintptr_t address, const T& value) noexcept {
        if (!IsConnected() || address < 0x10000) [[unlikely]] return false;
        return WriteProcessMemory(hProcess, reinterpret_cast<void*>(address), &value, sizeof(T), nullptr);
    }

    void ReadBuffer(uintptr_t address, void* buffer, size_t size) {
        if (!IsConnected() || !buffer || size == 0 || address < 0x10000) return;
        ReadProcessMemory(hProcess, reinterpret_cast<void*>(address), buffer, size, nullptr);
    }

    // RBX string (live-verified 12/10/2026): len int32 at +0x10, inline data at +0,
    // heap pointer at +0 when len >= 16. Pass the STRING OBJECT address.
    std::string ReadGameString(uintptr_t address) {
        if (!IsConnected() || address < 0x10000) return "";
        int32_t length = ReadMemory<int32_t>(address + 0x10);
        uintptr_t dataAddr = address;
        if (length >= 16) {
            dataAddr = ReadMemory<uintptr_t>(address);
            if (dataAddr < 0x10000) return "";
        }
        if (length > 0 && length < 4096) {
            std::string result; result.resize(length);
            SIZE_T got = 0;
            if (!ReadProcessMemory(hProcess, reinterpret_cast<void*>(dataAddr), result.data(), length, &got) || got == 0)
                return "";
            result.resize(static_cast<size_t>(got));
            if (auto np = result.find('\0'); np != std::string::npos) result.resize(np);
            return result;
        }
        // fallback: raw c-string scan
        char chunk[64]; std::string result; result.reserve(64);
        for (size_t off = 0; off < 512; off += sizeof(chunk)) {
            SIZE_T got = 0;
            if (!ReadProcessMemory(hProcess, reinterpret_cast<void*>(dataAddr + off), chunk, sizeof(chunk), &got) || got == 0) break;
            for (size_t i = 0; i < got; ++i) {
                if (chunk[i] == '\0') { result.append(chunk, i); return result; }
            }
            result.append(chunk, got);
            if (got < sizeof(chunk)) break;
        }
        return result;
    }

    inline bool IsConnected() const noexcept { return hProcess && hProcess != INVALID_HANDLE_VALUE; }
    inline uint32_t GetPID() const noexcept { return dwProcessId; }
    inline uintptr_t GetBase() const noexcept { return uModuleBase; }
    inline HANDLE GetHandle() const noexcept { return hProcess; }
};

inline std::unique_ptr<ProcessCommunicator> Coms = std::make_unique<ProcessCommunicator>();
