#include "ui_menu.h"
#include "ui_style.h"
#include "../../Core/Vars/Vars.h"
#include "../../Core/Globals/Globals.h"
#include "../../Memory/Communication.h"
#include "../../Game/Offsets/Offsets.h"
#include "../../Game/SDK/SDK.h"
#include <cstdio>
#include <algorithm>
#include <fstream>
#ifdef _WIN32
#include <Windows.h>
#endif

namespace CloserUI
{
    const char* KeyName(int vk) {
        if (vk == 0) return "None";
        switch (vk) {
            case 0x01: return "M1"; case 0x02: return "M2"; case 0x04: return "M3";
            case 0x05: return "M4"; case 0x06: return "M5"; case 0x10: return "SHIFT";
            case 0x11: return "CTRL"; case 0x12: return "ALT"; case 0x20: return "SPACE";
            case 0x2D: return "INS";
        }
        if (vk >= 0x41 && vk <= 0x5A) { static char b[2]; b[0]=(char)vk; b[1]=0; return b; }
        static char hx[8]; snprintf(hx, 8, "0x%02X", vk); return hx;
    }

    static const char* tabNames[] = {"Aim", "Silent", "Visuals", "Movement", "World", "Misc", "Config"};
    static const int numTabs = 7;

    static bool W_Checkbox(const char* lbl, bool* val) {
        auto* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        float sz = 16.f;
        ImGui::InvisibleButton(lbl, ImVec2(ImGui::GetContentRegionAvail().x, sz + 4));
        bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemClicked()) *val = !(*val);
        ImVec2 box(p.x, p.y + 2);
        ImU32 bg = *val ? ImGui::GetColorU32(Colors::Accent) : ImGui::GetColorU32(Colors::BgDark);
        ImU32 border = hov ? ImGui::GetColorU32(Colors::BorderHover) : ImGui::GetColorU32(Colors::Border);
        dl->AddRectFilled(box, ImVec2(box.x + sz, box.y + sz), bg, 3.f);
        dl->AddRect(box, ImVec2(box.x + sz, box.y + sz), border, 3.f);
        if (*val) {
            DrawGlow(dl, box, ImVec2(box.x + sz, box.y + sz), ImGui::GetColorU32(Colors::AccentGlow), 3.f, 6.f);
            // drawn tick (no font glyphs): two strokes
            dl->AddLine(ImVec2(box.x + 3.5f, box.y + 8.5f), ImVec2(box.x + 7, box.y + 12), ImGui::GetColorU32(Colors::BgDark), 2.f);
            dl->AddLine(ImVec2(box.x + 7, box.y + 12), ImVec2(box.x + 12.5f, box.y + 4.5f), ImGui::GetColorU32(Colors::BgDark), 2.f);
        }
        dl->AddText(ImVec2(box.x + sz + 8, box.y - 1),
            *val ? ImGui::GetColorU32(Colors::TextPrimary) : ImGui::GetColorU32(Colors::TextSecondary), lbl);
        ImGui::Dummy(ImVec2(10, 2));
        return *val;
    }

    static bool W_Slider(const char* lbl, float* val, float mn, float mx, const char* fmt = "%.1f") {
        auto* dl = ImGui::GetWindowDrawList();
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextSecondary));
        ImGui::Text("%s", lbl);
        ImGui::PopStyleColor();
        ImGui::SameLine(150);
        ImVec2 p = ImGui::GetCursorScreenPos();
        float w = 100.f, h = 5.f;
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), ImGui::GetColorU32(Colors::BgDark), 3.f);
        float t = (*val - mn) / (mx - mn);
        if (t > 0) {
            dl->AddRectFilled(p, ImVec2(p.x + w * t, p.y + h), ImGui::GetColorU32(Colors::Accent), 3.f);
            DrawGlow(dl, p, ImVec2(p.x + w * t, p.y + h), ImGui::GetColorU32(Colors::AccentGlow), 3.f, 4.f);
        }
        ImGui::SetCursorScreenPos(p);
        ImGui::InvisibleButton(lbl, ImVec2(w, h + 10));
        if (ImGui::IsItemActive()) {
            float nt = std::clamp((ImGui::GetIO().MousePos.x - p.x) / w, 0.f, 1.f);
            *val = mn + nt * (mx - mn);
        }
        ImGui::SameLine();
        char buf[32]; snprintf(buf, 32, fmt, *val);
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::Accent));
        ImGui::Text("%s", buf);
        ImGui::PopStyleColor();
        return ImGui::IsItemActive();
    }

    static bool W_Combo(const char* lbl, int* val, const char* const items[], int cnt) {
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextSecondary));
        ImGui::Text("%s", lbl);
        ImGui::PopStyleColor();
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10, 6));
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImGui::GetColorU32(Colors::BgDark));
        ImGui::PushStyleColor(ImGuiCol_PopupBg, ImGui::GetColorU32(Colors::BgLight));
        ImGui::SetNextItemWidth(-1);
        char id[64]; snprintf(id, 64, "##%s", lbl);
        bool ch = ImGui::Combo(id, val, items, cnt);
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar();
        return ch;
    }

    // Keybind capture button bound to an int vk. id selects listening slot.
    static void W_Keybind(int* vk, int id) {
        bool listening = (g_State.listening == id);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 4));
        ImGui::PushStyleColor(ImGuiCol_Button, listening ? ImGui::GetColorU32(Colors::Accent) : ImGui::GetColorU32(Colors::BgDark));
        if (ImGui::Button(listening ? "..." : KeyName(*vk), ImVec2(64, 22))) g_State.listening = id;
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
        if (listening) {
#ifdef _WIN32
            for (int c = 0x01; c <= 0xFE; c++) {
                if (GetAsyncKeyState(c) & 0x8000) {
                    if (c == VK_ESCAPE) { *vk = 0; }
                    else *vk = c;
                    g_State.listening = 0;
                    break;
                }
            }
#endif
        }
    }

    // muted one-line description under a control or group. Keeps the menu self-explaining.
    static void Hint(const char* t) {
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextMuted));
        ImGui::TextWrapped("%s", t);
        ImGui::PopStyleColor();
    }

    static void GroupStart(const char* title, float h) {        auto* dl = ImGui::GetWindowDrawList();
        float w = ImGui::GetContentRegionAvail().x;
        if (w < 50) w = 50;
        float hh = h > 0 ? h : 200;
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + hh), ImGui::GetColorU32(Colors::BgPanel), Dim::Rounding);
        dl->AddRect(p, ImVec2(p.x + w, p.y + hh), ImGui::GetColorU32(Colors::Border), Dim::Rounding);
        dl->AddText(ImVec2(p.x + 12, p.y + 8), ImGui::GetColorU32(Colors::Accent), title);
        ImGui::Dummy(ImVec2(w, 28));
        ImGui::Indent(12);
        ImGui::BeginChild(title, ImVec2(w - 24, hh - 40), false);
    }
    static void GroupEnd() {
        ImGui::EndChild();
        ImGui::Unindent(12);
        ImGui::Spacing();
    }

    static void SaveCfg() {
        std::ofstream f("closer.cfg");
        f << "aim " << Vars::Aimbot::enabled << "\n";
        f << "aimfov " << Vars::Aimbot::fovRadius << "\n";
        f << "aimsmooth " << Vars::Aimbot::smoothing << "\n";
        f << "aimkey " << Vars::Aimbot::aimbotKey << "\n";
        f << "hitpart " << Vars::Aimbot::hitPart << "\n";
        f << "method " << Vars::Aimbot::aimMethod << "\n";
        f << "silent " << Vars::Silent::enabled << "\n";
        f << "silentfov " << Vars::Silent::fovRadius << "\n";
        f << "silentsmooth " << Vars::Silent::smoothing << "\n";
        f << "silentkey " << Vars::Silent::silentKey << "\n";
        f << "esp " << Vars::ESP::enabled << "\n";
        f << "speed " << Vars::Character::speedEnabled << " " << Vars::Character::walkSpeed << "\n";
        f << "fly " << Vars::Character::flyEnabled << " " << Vars::Character::flySpeed << "\n";
        f << "jump " << Vars::Character::jumpEnabled << " " << Vars::Character::jumpPower << "\n";
        f << "noclip " << Vars::Character::noclip << "\n";
        f << "accent " << Vars::Style::accent[0] << " " << Vars::Style::accent[1] << " " << Vars::Style::accent[2] << "\n";
    }
    static void LoadCfg() {
        std::ifstream f("closer.cfg");
        std::string k;
        while (f >> k) {
            if (k == "aim") f >> Vars::Aimbot::enabled;
            else if (k == "aimfov") f >> Vars::Aimbot::fovRadius;
            else if (k == "aimsmooth") f >> Vars::Aimbot::smoothing;
            else if (k == "aimkey") f >> Vars::Aimbot::aimbotKey;
            else if (k == "hitpart") f >> Vars::Aimbot::hitPart;
            else if (k == "method") f >> Vars::Aimbot::aimMethod;
            else if (k == "silent") f >> Vars::Silent::enabled;
            else if (k == "silentfov") f >> Vars::Silent::fovRadius;
            else if (k == "silentsmooth") f >> Vars::Silent::smoothing;
            else if (k == "silentkey") f >> Vars::Silent::silentKey;
            else if (k == "esp") f >> Vars::ESP::enabled;
            else if (k == "speed") f >> Vars::Character::speedEnabled >> Vars::Character::walkSpeed;
            else if (k == "fly") f >> Vars::Character::flyEnabled >> Vars::Character::flySpeed;
            else if (k == "jump") f >> Vars::Character::jumpEnabled >> Vars::Character::jumpPower;
            else if (k == "noclip") f >> Vars::Character::noclip;
            else if (k == "accent") f >> Vars::Style::accent[0] >> Vars::Style::accent[1] >> Vars::Style::accent[2];
            else { std::string skip; std::getline(f, skip); }
        }
    }

    static void TabAim() {
        Hint("Aimbot moves your cursor or camera onto the target while you hold the key.");
        ImGui::Spacing();
        ImGui::Columns(2, 0, false);
        ImGui::SetColumnWidth(0, 300);
        GroupStart("Aimbot", 400);
        W_Checkbox("Enabled", &Vars::Aimbot::enabled);
        W_Checkbox("Toggle mode (press once, no hold)", &Vars::Aimbot::toggle);
        W_Checkbox("Sticky lock (hold through brief loss)", &Vars::Aimbot::stickyLock);
        W_Checkbox("Team check (skip teammates)", &Vars::Aimbot::teamCheck);
        W_Checkbox("Health check (skip the dead)", &Vars::Aimbot::healthCheck);
        W_Checkbox("Knock check (DaHood downed, experimental)", &Vars::Aimbot::knockCheck);
        W_Checkbox("Wall check (drop behind camera, experimental)", &Vars::Aimbot::wallCheck);
        const char* parts[] = {"Head","Torso","L Arm","R Arm","L Leg","R Leg","Closest"};
        W_Combo("Hit part (where it locks)", &Vars::Aimbot::hitPart, parts, 7);
        const char* mt[] = {"Mouse (moves cursor)","Memory camlock (experimental)"};
        W_Combo("Aim type", &Vars::Aimbot::aimMethod, mt, 2);
        ImGui::Text("Hold key"); ImGui::SameLine(190); W_Keybind(&Vars::Aimbot::aimbotKey, 1);
        GroupEnd();
        ImGui::NextColumn();
        GroupStart("Tuning", 400);
        W_Slider("FOV size", &Vars::Aimbot::fovRadius, 10.f, 600.f, "%.0f");
        Hint("Circle around your cursor. Only targets inside it can lock.");
        W_Checkbox("Show FOV circle", &Vars::Aimbot::showFOV);
        W_Checkbox("Fill FOV circle", &Vars::Aimbot::fillFOV);
        W_Slider("Circle detail", &Vars::Aimbot::fovSmooth, 1.f, 5.f, "%.0f");
        W_Slider("Smoothing (lower = snappier)", &Vars::Aimbot::smoothing, 1.f, 30.f);
        W_Slider("Prediction sec (lead movers, 0.12 DaHood)", &Vars::Aimbot::prediction, 0.f, 0.5f, "%.3f");
        W_Slider("Max dist m (0 = unlimited)", &Vars::Aimbot::distance, 0.f, 2000.f, "%.0f");
        W_Checkbox("Triggerbot (auto-fire on head)", &Vars::Aimbot::triggerbot);
        W_Checkbox("Target hover (highlight lock)", &Vars::Aimbot::targetHover);
        W_Checkbox("Death unlock (drop instantly on kill)", &Vars::Aimbot::deathUnlock);
        W_Slider("Max lock sec (0 = infinite)", &Vars::Aimbot::maxLockTime, 0.f, 15.f);
        W_Slider("Relock delay sec", &Vars::Aimbot::relockDelay, 0.f, 1.f, "%.2f");
        GroupEnd();
        ImGui::Columns(1);
    }

    static void TabSilent() {
        Hint("Silent curves your aim toward targets in its circle. On-fire mode only touches aim while shooting, so it looks legit.");
        ImGui::Spacing();
        ImGui::Columns(2, 0, false);
        ImGui::SetColumnWidth(0, 300);
        GroupStart("Silent aim", 440);
        W_Checkbox("Enabled", &Vars::Silent::enabled);
        W_Checkbox("Auto (no key, always hunting)", &Vars::Silent::autoFire);
        W_Checkbox("Only while firing (true silent feel)", &Vars::Silent::onFireOnly);
        W_Checkbox("Magic bullet (wide snap preset)", &Vars::Silent::magicBullet);
        Hint("Magic bullet sets FOV 300 + smoothing 2 + auto, restores after.");
        W_Checkbox("Wall check (experimental)", &Vars::Silent::wallCheck);
        W_Checkbox("Knock check (experimental)", &Vars::Silent::knockCheck);
        W_Checkbox("Target snapline (proof line)", &Vars::Silent::showSnapline);
        const char* hp[] = {"Head","Body"};
        W_Combo("Hit part", &Vars::Silent::hitPart, hp, 2);
        const char* sm[] = {"Mouse curve (works)","Memory camlock (experimental)"};
        W_Combo("Method", &Vars::Silent::method, sm, 2);
        W_Slider("Smoothing (higher = more legit)", &Vars::Silent::smoothing, 1.f, 30.f);
        W_Slider("Prediction sec", &Vars::Silent::prediction, 0.f, 0.5f, "%.3f");
        W_Slider("Max dist m (0 = unlimited)", &Vars::Silent::distance, 0.f, 2000.f, "%.0f");
        ImGui::Text("Hold key"); ImGui::SameLine(190); W_Keybind(&Vars::Silent::silentKey, 2);
        GroupEnd();
        ImGui::NextColumn();
        GroupStart("Silent FOV", 240);
        W_Checkbox("Show circle", &Vars::Silent::showFOV);
        W_Checkbox("Fill circle", &Vars::Silent::fillFOV);
        W_Slider("Size", &Vars::Silent::fovRadius, 10.f, 600.f, "%.0f");
        W_Slider("Circle detail", &Vars::Silent::fovSmooth, 1.f, 5.f, "%.0f");
        Hint("Shots only bend toward targets inside this circle.");
        GroupEnd();
        ImGui::Columns(1);
    }

    static void TabVisuals() {
        {
            Hint("Boxes, bars and bones. Unlimited distance by default (0 = see everyone).");
            ImGui::Spacing();
            ImGui::Columns(2, 0, false);
            ImGui::SetColumnWidth(0, 300);
            GroupStart("Player ESP", 430);
            W_Checkbox("Enabled", &Vars::ESP::enabled);
            W_Checkbox("Team check", &Vars::ESP::teamCheck);
            W_Checkbox("Self ESP", &Vars::ESP::selfESP);
            W_Checkbox("Outline", &Vars::ESP::outline);
            W_Checkbox("Box", &Vars::ESP::boxes);
            W_Checkbox("Fill box", &Vars::ESP::fillBox);
            W_Slider("Fill alpha", &Vars::ESP::fillAlpha, 0.05f, 0.8f, "%.2f");
            W_Checkbox("Name", &Vars::ESP::names);
            const char* nm[] = {"Username","Display"};
            W_Combo("Name mode", &Vars::ESP::nameMode, nm, 2);
            W_Checkbox("Health bar", &Vars::ESP::healthBar);
            W_Checkbox("Distance", &Vars::ESP::distanceText);
            W_Checkbox("Equipped item", &Vars::ESP::equipped);
            W_Checkbox("Skeleton", &Vars::ESP::skeleton);
            W_Checkbox("Head dot", &Vars::ESP::headDot);
            GroupEnd();
            ImGui::NextColumn();
            GroupStart("Overlays", 430);
            const char* tm[] = {"Off","Bottom","Top","Middle","Mouse"};
            W_Combo("Tracer", &Vars::ESP::tracerMode, tm, 5);
            W_Checkbox("Chams glow", &Vars::ESP::chams);
            const char* cm[] = {"Ghost","Glow"};
            W_Combo("Cham mode", &Vars::ESP::chamMode, cm, 2);
            W_Checkbox("Chams filled", &Vars::ESP::chamsFilled);
            W_Slider("Max dist", &Vars::ESP::distance, 0.f, 5000.f, "%.0f");
            W_Checkbox("Radar", &Vars::ESP::radar);
            Hint("Top-right minimap. Zoom scales how far blips reach.");
            W_Slider("Radar size", &Vars::ESP::radarSize, 80.f, 300.f, "%.0f");
            W_Slider("Radar zoom", &Vars::ESP::radarZoom, 0.5f, 4.f, "%.1f");
            GroupEnd();
            ImGui::Columns(1);
        }
    }

    static void TabWorld() {
        {
            Hint("Your camera and the map atmosphere. All writes are validated before sending.");
            ImGui::Spacing();
            ImGui::Columns(2, 0, false);
            ImGui::SetColumnWidth(0, 300);
            GroupStart("Camera", 220);
            W_Checkbox("Third person (force shoulder cam)", &Vars::Camera::thirdPerson);
            W_Slider("Distance", &Vars::Camera::thirdDist, 4.f, 40.f, "%.0f");
            W_Checkbox("FOV changer", &Vars::Camera::fovChanger);
            W_Slider("FOV", &Vars::Camera::customFOV, 30.f, 120.f, "%.0f");
            Hint("Restores 70 automatically when toggled off.");
            GroupEnd();
            ImGui::NextColumn();
            GroupStart("Atmosphere", 240);
            W_Checkbox("Custom fog", &Vars::World::customFog);
            ImGui::ColorEdit3("Fog color", Vars::World::fogColor);
            W_Checkbox("Glow (ambient boost)", &Vars::World::glow);
            W_Checkbox("Fullbright", &Vars::World::fullbright);
            W_Checkbox("No fog (max draw)", &Vars::World::noFog);
            GroupEnd();
            ImGui::Columns(1);
        }
    }

    static void TabMovement() {
        Hint("Speed, flight and hops write your local humanoid. HvH movement sends real key input.");
        ImGui::Spacing();
        ImGui::Columns(2, 0, false);
        ImGui::SetColumnWidth(0, 300);
        GroupStart("Protection", 150);
        W_Checkbox("Anti fling (clamp wild velocity)", &Vars::Character::antiFling);
        W_Checkbox("Noclip (walk through walls)", &Vars::Character::noclip);
        GroupEnd();
        ImGui::NextColumn();
        GroupStart("Movement", 360);
        W_Checkbox("Speed", &Vars::Character::speedEnabled);
        W_Slider("WalkSpeed", &Vars::Character::walkSpeed, 16.f, 300.f, "%.0f");
        W_Checkbox("Flight (hold key + WASD)", &Vars::Character::flyEnabled);
        W_Slider("Fly speed", &Vars::Character::flySpeed, 10.f, 300.f, "%.0f");
        ImGui::Text("Fly key"); ImGui::SameLine(190); W_Keybind(&Vars::Character::flyKey, 3);
        W_Checkbox("Jump power", &Vars::Character::jumpEnabled);
        W_Slider("JumpPower", &Vars::Character::jumpPower, 50.f, 300.f, "%.0f");
        W_Checkbox("Float (hover at locked height)", &Vars::Character::floatEnabled);
        Hint("Float: Space rises, Shift sinks, release holds height.");
        GroupEnd();
        ImGui::Columns(1);
        ImGui::Spacing();
        GroupStart("HvH movement (real input, undetected style)", 260);
        W_Checkbox("Backtrack (aim at old records)", &Vars::HvH::backtrack);
        W_Slider("Backtrack ms", &Vars::HvH::backtrackMs, 50.f, 400.f, "%.0f");
        W_Checkbox("Bhop (auto-jump while held)", &Vars::HvH::bhop);
        ImGui::Text("Bhop key"); ImGui::SameLine(190); W_Keybind(&Vars::HvH::bhopKey, 4);
        W_Checkbox("Autostrafe (A/D in air)", &Vars::HvH::autostrafe);
        W_Checkbox("Edgejump (hop off edges)", &Vars::HvH::edgejump);
        GroupEnd();
        ImGui::Spacing();
        GroupStart("Waypoints (save spot, TP back)", 240);
        Hint("Save stores where you stand. Load teleports you back.");
        for (int i = 0; i < 5; i++) {
            char lbl[32]; snprintf(lbl, sizeof(lbl), "Slot %d %s", i + 1, Vars::Waypoints::slot[i].set ? "(set)" : "(empty)");
            if (ImGui::Button((std::string("Save ") + lbl).c_str(), ImVec2(200, 22))) {
                auto ch = Globals::localPlayer.GetModelRef();
                auto root = ch ? ch.FindChild("HumanoidRootPart") : RBX::RbxInstance(0);
                if (root) { auto p = root.GetPos(); Vars::Waypoints::slot[i] = {p.X, p.Y, p.Z, true}; }
            }
            ImGui::SameLine();
            if (ImGui::Button((std::string("Load ") + lbl).c_str(), ImVec2(200, 22))) {
                if (Vars::Waypoints::slot[i].set) {
                    auto ch = Globals::localPlayer.GetModelRef();
                    auto root = ch ? ch.FindChild("HumanoidRootPart") : RBX::RbxInstance(0);
                    if (root) {
                        uintptr_t prim = Coms->ReadMemory<uintptr_t>(root.Addr + offsets::Primitive);
                        if (prim) { RBX::Vec3 p{Vars::Waypoints::slot[i].x, Vars::Waypoints::slot[i].y, Vars::Waypoints::slot[i].z}; Coms->WriteMemory<RBX::Vec3>(prim + offsets::Position, p); }
                    }
                }
            }
        }
        GroupEnd();
    }

    static void TabMisc() {
        Hint("Firing helpers, overlays and safety. Everything here works over real input or overlay only.");
        ImGui::Spacing();
        ImGui::Columns(2, 0, false);
        ImGui::SetColumnWidth(0, 300);
        GroupStart("Firing", 300);
        W_Checkbox("Triggerbot (fire on head, hold X2)", &Vars::Misc::triggerbot);
        float td = (float)Vars::Misc::triggerDelayMs;
        W_Slider("Trigger delay ms", &td, 0.f, 500.f, "%.0f");
        Vars::Misc::triggerDelayMs = (int)td;
        W_Checkbox("Rapid fire (auto-click while held)", &Vars::Misc::rapidFire);
        const char* rk[] = {"LMB", "RMB", "MMB", "X1", "X2"};
        const int rkv[] = {1, 2, 4, 5, 6};
        int rki = 0;
        for (int i = 0; i < 5; i++) if (rkv[i] == Vars::Misc::rapidKey) rki = i;
        W_Combo("Rapid key", &rki, rk, 5);
        Vars::Misc::rapidKey = rkv[rki];
        float ri = (float)Vars::Misc::rapidIntervalMs;
        W_Slider("Click interval ms", &ri, 10.f, 500.f, "%.0f");
        Vars::Misc::rapidIntervalMs = (int)ri;
        GroupEnd();
        ImGui::NextColumn();
        GroupStart("Overlays + safety", 330);
        W_Checkbox("Streamproof (invisible on Discord/OBS)", &Vars::Style::streamproof);
        Hint("Takes effect instantly, no restart.");
        W_Checkbox("Crosshair", &Vars::Misc::crosshair);
        W_Checkbox("Hitmarker on kill", &Vars::Misc::hitmarker);
        W_Checkbox("Hit beep", &Vars::Misc::hitSound);
        W_Checkbox("Player list window", &Vars::Misc::playerList);
        Hint("Live table of cached names, HP and distance. If it is empty, nothing else can lock either.");
        ImGui::Text("Panic key (all off + hide)"); ImGui::SameLine(190); W_Keybind(&Vars::Misc::panicKey, 5);
        GroupEnd();
        ImGui::Columns(1);
    }

    static void TabConfig() {
        Hint("Save named builds, restyle the menu, one-click legit. INSERT toggles menu, END exits, F9 panics.");
        ImGui::Spacing();
        ImGui::Columns(2, 0, false);
        ImGui::SetColumnWidth(0, 300);
        GroupStart("Config files", 300);
        static char cfgName[32] = "legit";
        ImGui::InputText("##cfgname", cfgName, sizeof(cfgName));
        Hint("Type a name, Save stores it, Load recalls it.");
        std::string cf = std::string("closer_") + cfgName + ".cfg";
        if (ImGui::Button("Save", ImVec2(-1, 28))) { CopyFileA("closer.cfg", "closer_last.cfg", FALSE); SaveCfg(); CopyFileA("closer.cfg", cf.c_str(), FALSE); }
        if (ImGui::Button("Load", ImVec2(-1, 28))) { if (CopyFileA(cf.c_str(), "closer.cfg", FALSE)) LoadCfg(); }
        if (ImGui::Button("Delete", ImVec2(-1, 28))) DeleteFileA(cf.c_str());
        ImGui::Spacing();
        const char* presets[] = {"legit", "rage", "closer"};
        for (int i = 0; i < 3; i++) {
            std::string pf = std::string("closer_") + presets[i] + ".cfg";
            if (ImGui::Button(presets[i], ImVec2(-1, 24))) { if (CopyFileA(pf.c_str(), "closer.cfg", FALSE)) LoadCfg(); }
        }
        ImGui::Spacing();
        if (ImGui::Button("Apply LEGIT preset", ImVec2(-1, 28))) {
            Vars::Aimbot::smoothing = 15.0f; Vars::Aimbot::fovRadius = 60.0f;
            Vars::Silent::smoothing = 20.0f; Vars::Silent::fovRadius = 60.0f;
            Vars::Silent::autoFire = true; Vars::Silent::onFireOnly = true;
            Vars::Silent::magicBullet = false;
            Vars::Aimbot::triggerbot = false; Vars::HvH::backtrack = false;
        }
        Hint("Legit: tight circles, slow curves, fire-only silent, no snap.");
        GroupEnd();
        ImGui::NextColumn();
        GroupStart("Menu style", 300);
        ImGui::Text("Accent presets (click one)");
        struct AP { const char* n; float r, g, b; };
        AP presetsA[] = {{"Violet",0.65f,0.4f,1.0f},{"Pink",0.95f,0.35f,0.6f},{"Cyan",0.25f,0.8f,1.0f},
                         {"Green",0.35f,1.0f,0.55f},{"Red",1.0f,0.3f,0.3f},{"Gold",1.0f,0.75f,0.25f}};
        for (int i = 0; i < 6; i++) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(presetsA[i].r, presetsA[i].g, presetsA[i].b, 1.f));
            char pb[16]; snprintf(pb, sizeof(pb), "##ap%d", i);
            if (ImGui::Button(pb, ImVec2(28, 20))) {
                Vars::Style::accent[0] = presetsA[i].r; Vars::Style::accent[1] = presetsA[i].g; Vars::Style::accent[2] = presetsA[i].b;
            }
            ImGui::PopStyleColor();
            if (i < 5) ImGui::SameLine();
        }
        ImGui::ColorEdit3("Custom accent", Vars::Style::accent);
        Hint("Applies instantly across menu, FOV rings and watermark.");
        W_Checkbox("Streamproof (hide from capture)", &Vars::Style::streamproof);
        W_Checkbox("Hide console after connect", &Vars::Style::hideConsole);
        GroupEnd();
        ImGui::Columns(1);
    }

    void RenderMenu() {        if (!Vars::menuOpen) return;
        ImGui::SetNextWindowSize(ImVec2(Dim::WinWidth, Dim::WinHeight), ImGuiCond_FirstUseEver);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        int flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar;
        if (ImGui::Begin("##closer", &Vars::menuOpen, flags)) {
            auto* dl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetWindowPos();
            ImVec2 sz = ImGui::GetWindowSize();
            // drag strip: hold the accent bar to move the menu
            ImGui::SetCursorScreenPos(p);
            ImGui::InvisibleButton("##drag", ImVec2(sz.x, 10));
            static bool dragging = false;
            if (ImGui::IsItemActivated()) dragging = true;
            if (dragging) {
                if (!ImGui::IsMouseDown(0)) dragging = false;
                else {
                    ImVec2 dd = ImGui::GetIO().MouseDelta;
                    ImVec2 np = ImGui::GetWindowPos();
                    ImGui::SetWindowPos("##closer", ImVec2(np.x + dd.x, np.y + dd.y), ImGuiCond_Always);
                    p = ImGui::GetWindowPos();
                }
            }
            ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + 10));
            ImGui::Dummy(ImVec2(1, 1));
            dl->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + 2), ImGui::GetColorU32(Colors::Accent), Dim::Rounding, ImDrawFlags_RoundCornersTop);
            DrawGlow(dl, p, ImVec2(p.x + sz.x, p.y + 2), ImGui::GetColorU32(Colors::AccentGlow), 0, 10.f);
            // skeet-style top strip: logo left, tabs fill the rest (never wraps)
            ImGui::BeginChild("##topbar", ImVec2(0, 54), false);
            {
                ImGui::Indent(14);
                ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::AccentLight));
                ImGui::SetWindowFontScale(1.3f);
                ImGui::Text("closer.lol");
                ImGui::SetWindowFontScale(1.f);
                ImGui::PopStyleColor();
                ImGui::SameLine(0, 8);
                ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextMuted));
                ImGui::Text("v8");
                ImGui::PopStyleColor();
                ImGui::SameLine(0, 18);
                float avail = ImGui::GetContentRegionAvail().x - 14;
                float btnW = (avail - 6 * 6) / 7;
                if (btnW < 70) btnW = 70;
                for (int i = 0; i < numTabs; i++) {
                    bool sel = (g_State.curtab == i);
                    if (sel) {
                        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(Colors::Accent.x, Colors::Accent.y, Colors::Accent.z, 0.85f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImGui::GetColorU32(Colors::AccentGlow));
                        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.08f, 0.08f, 0.1f, 1.f));
                    } else {
                        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(Colors::Accent.x, Colors::Accent.y, Colors::Accent.z, 0.18f));
                        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextSecondary));
                    }
                    char lbl[64]; snprintf(lbl, sizeof(lbl), "%s##t%d", tabNames[i], i);
                    if (ImGui::Button(lbl, ImVec2(btnW, 30))) { g_State.curtab = i; g_State.subtab = 0; }
                    ImGui::PopStyleColor(3);
                    if (i < numTabs - 1) ImGui::SameLine(0, 6);
                }
                ImGui::Unindent(14);
            }
            ImGui::EndChild();
            ImGui::Separator();
            ImGui::BeginChild("##content", ImVec2(0, 0), false);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18, 18));
            ImGui::BeginChild("##inner", ImVec2(0, 0), false);
            ImGui::SetWindowFontScale(1.25f);
            ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextPrimary));
            ImGui::Text("%s", tabNames[g_State.curtab]);
            ImGui::PopStyleColor();
            ImGui::SetWindowFontScale(1.f);
            ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing(); ImGui::Spacing();
            switch (g_State.curtab) {
                case 0: TabAim(); break;
                case 1: TabSilent(); break;
                case 2: TabVisuals(); break;
                case 3: TabMovement(); break;
                case 4: TabWorld(); break;
                case 5: TabMisc(); break;
                case 6: TabConfig(); break;
            }
            ImGui::EndChild();
            ImGui::PopStyleVar();
            ImGui::EndChild();
        }
        ImGui::End();
        ImGui::PopStyleVar();
    }

    bool RenderKeyGate() {
        static char buf[64] = "";
        static bool triedFile = false;
        static std::string err = "";
        static bool shake = false;
        static DWORD shakeUntil = 0;
        if (!triedFile) {
            triedFile = true;
            std::ifstream kf("closer.key");
            std::string saved;
            if (kf >> saved && saved == "key") return true;
        }
        ImGuiViewport* vp = ImGui::GetMainViewport();
        ImVec2 cs(360, 220);
        ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x / 2 - cs.x / 2, vp->Pos.y + vp->Size.y / 2 - cs.y / 2), ImGuiCond_Always);
        ImGui::SetNextWindowSize(cs, ImGuiCond_Always);
        int flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar;
        DWORD now = GetTickCount();
        bool authed = false;
        if (ImGui::Begin("##keygate", nullptr, flags)) {
            auto* dl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetWindowPos();
            ImVec2 sz = ImGui::GetWindowSize();
            float ox = (shake && now < shakeUntil) ? sinf(now * 0.05f) * 6.0f : 0.0f;
            if (ox != 0) { ImVec2 wp = ImGui::GetWindowPos(); ImGui::SetWindowPos("##keygate", ImVec2(wp.x + ox * 0.2f, wp.y), ImGuiCond_Always); }
            dl->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + 3), ImGui::GetColorU32(Colors::Accent), 5.f, ImDrawFlags_RoundCornersTop);
            DrawGlow(dl, p, ImVec2(p.x + sz.x, p.y + 3), ImGui::GetColorU32(Colors::AccentGlow), 0, 10.f);
            ImGui::Dummy(ImVec2(1, 14));
            ImGui::Indent(28);
            ImGui::SetWindowFontScale(1.5f);
            ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::AccentLight));
            ImGui::Text("closer.lol");
            ImGui::PopStyleColor();
            ImGui::SetWindowFontScale(1.f);
            ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetColorU32(Colors::TextMuted));
            ImGui::Text("enter your key to continue");
            ImGui::PopStyleColor();
            ImGui::Spacing();
            ImGui::PushItemWidth(280);
            bool go = ImGui::InputTextWithHint("##keyin", "key...", buf, sizeof(buf), ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::PopItemWidth();
            ImGui::Spacing();
            if (ImGui::Button("Unlock", ImVec2(280, 32))) go = true;
            if (!err.empty()) {
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 110, 110, 255));
                ImGui::Text("%s", err.c_str());
                ImGui::PopStyleColor();
            }
            if (go) {
                if (std::string(buf) == "key") {
                    std::ofstream kf("closer.key");
                    kf << "key";
                    memset(buf, 0, sizeof(buf));
                    authed = true;
                } else {
                    err = "wrong key, try again";
                    shake = true; shakeUntil = now + 400;
                }
            }
            ImGui::Unindent(28);
        }
        ImGui::End();
        if (shake && now >= shakeUntil) shake = false;
        return authed;
    }
}
