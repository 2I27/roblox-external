#pragma once
// closer.lol menu shell on Phantom-style core: tabs drive Vars:: directly.
#include "../ImGui/imgui.h"
#include <string>

namespace CloserUI
{
    struct MenuState {
        bool open = true;
        int curtab = 0;
        int subtab = 0;
        // keybind capture: which action is listening
        int listening = 0; // 0 none, 1 aim, 2 silent
        // logo texture (set by overlay after WIC load; may stay null)
        void* logoTex = nullptr;
        int logoW = 0, logoH = 0;
    };
    inline MenuState g_State;

    void RenderMenu();
    // GUI key gate: centered panel, remember-key file. Returns true when authed.
    bool RenderKeyGate();
    const char* KeyName(int vk);
}
