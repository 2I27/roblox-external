#include "ui_style.h"

namespace CloserUI
{
    void SyncAccent(float r, float g, float b)
    {
        Colors::Accent = ImVec4(r, g, b, 1.0f);
        Colors::AccentLight = ImVec4(r + (1 - r) * 0.25f, g + (1 - g) * 0.25f, b + (1 - b) * 0.25f, 1.0f);
        Colors::AccentGlow = ImVec4(r + (1 - r) * 0.4f, g + (1 - g) * 0.4f, b + (1 - b) * 0.4f, 1.0f);
        Colors::AccentDark = ImVec4(r * 0.7f, g * 0.7f, b * 0.7f, 1.0f);
        Colors::Border = ImVec4(r, g, b, 0.15f);
        Colors::BorderHover = ImVec4(r, g, b, 0.40f);
        Colors::BorderActive = ImVec4(r, g, b, 0.60f);
    }

    void InitStyle()
    {
        ImGuiStyle& s = ImGui::GetStyle();
        using namespace Colors;
        s.WindowPadding = ImVec2(0, 0);
        s.FramePadding = ImVec2(8, 6);
        s.CellPadding = ImVec2(6, 4);
        s.ItemSpacing = ImVec2(8, 6);
        s.ItemInnerSpacing = ImVec2(6, 4);
        s.ScrollbarSize = 8.f;
        s.GrabMinSize = 10.f;
        s.WindowBorderSize = 1.f;
        s.ChildBorderSize = 1.f;
        s.PopupBorderSize = 1.f;
        s.FrameBorderSize = 1.f;
        s.WindowRounding = Dim::Rounding;
        s.ChildRounding = Dim::Rounding;
        s.FrameRounding = Dim::RoundingSm;
        s.PopupRounding = Dim::Rounding;
        s.ScrollbarRounding = Dim::RoundingSm;
        s.GrabRounding = Dim::RoundingSm;
        s.TabRounding = Dim::RoundingSm;
        ImVec4* c = s.Colors;
        c[ImGuiCol_WindowBg] = BgMedium;
        c[ImGuiCol_ChildBg] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_PopupBg] = BgLight;
        c[ImGuiCol_Border] = Border;
        c[ImGuiCol_BorderShadow] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_Text] = TextPrimary;
        c[ImGuiCol_TextDisabled] = TextDisabled;
        c[ImGuiCol_FrameBg] = BgDark;
        c[ImGuiCol_FrameBgHovered] = BgLight;
        c[ImGuiCol_FrameBgActive] = BgLight;
        c[ImGuiCol_TitleBg] = BgDark;
        c[ImGuiCol_TitleBgActive] = BgDark;
        c[ImGuiCol_TitleBgCollapsed] = BgDark;
        c[ImGuiCol_MenuBarBg] = BgDark;
        c[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_ScrollbarGrab] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_ScrollbarGrabActive] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_CheckMark] = AccentGlow;
        c[ImGuiCol_SliderGrab] = Accent;
        c[ImGuiCol_SliderGrabActive] = AccentGlow;
        c[ImGuiCol_Button] = BgLight;
        c[ImGuiCol_ButtonHovered] = ImVec4(Accent.x, Accent.y, Accent.z, 0.3f);
        c[ImGuiCol_ButtonActive] = ImVec4(Accent.x, Accent.y, Accent.z, 0.5f);
        c[ImGuiCol_Header] = ImVec4(Accent.x, Accent.y, Accent.z, 0.15f);
        c[ImGuiCol_HeaderHovered] = ImVec4(Accent.x, Accent.y, Accent.z, 0.25f);
        c[ImGuiCol_HeaderActive] = ImVec4(Accent.x, Accent.y, Accent.z, 0.35f);
        c[ImGuiCol_Separator] = Border;
        c[ImGuiCol_SeparatorHovered] = Accent;
        c[ImGuiCol_SeparatorActive] = AccentGlow;
        c[ImGuiCol_ResizeGrip] = ImVec4(Accent.x, Accent.y, Accent.z, 0.2f);
        c[ImGuiCol_ResizeGripHovered] = ImVec4(Accent.x, Accent.y, Accent.z, 0.4f);
        c[ImGuiCol_ResizeGripActive] = AccentGlow;
        c[ImGuiCol_Tab] = BgDark;
        c[ImGuiCol_TabHovered] = ImVec4(Accent.x, Accent.y, Accent.z, 0.3f);
        c[ImGuiCol_TabActive] = ImVec4(Accent.x, Accent.y, Accent.z, 0.2f);
        c[ImGuiCol_TabUnfocused] = BgDark;
        c[ImGuiCol_TabUnfocusedActive] = BgLight;
        c[ImGuiCol_PlotLines] = Accent;
        c[ImGuiCol_PlotLinesHovered] = AccentGlow;
        c[ImGuiCol_PlotHistogram] = Accent;
        c[ImGuiCol_PlotHistogramHovered] = AccentGlow;
        c[ImGuiCol_TableHeaderBg] = BgDark;
        c[ImGuiCol_TableBorderStrong] = Border;
        c[ImGuiCol_TableBorderLight] = ImVec4(Border.x, Border.y, Border.z, Border.w * 0.5f);
        c[ImGuiCol_TableRowBg] = ImVec4(0, 0, 0, 0);
        c[ImGuiCol_TableRowBgAlt] = ImVec4(1, 1, 1, 0.02f);
        c[ImGuiCol_TextSelectedBg] = ImVec4(Accent.x, Accent.y, Accent.z, 0.35f);
        c[ImGuiCol_DragDropTarget] = AccentGlow;
        c[ImGuiCol_NavHighlight] = Accent;
        c[ImGuiCol_NavWindowingHighlight] = AccentGlow;
        c[ImGuiCol_NavWindowingDimBg] = ImVec4(0, 0, 0, 0.5f);
        c[ImGuiCol_ModalWindowDimBg] = ImVec4(0, 0, 0, 0.6f);
    }

    void DrawGlow(ImDrawList* dl, ImVec2 mn, ImVec2 mx, ImU32 col, float r, float sz)
    {
        for (int i = 0; i < 4; i++)
        {
            float expand = sz * (i + 1) / 4.f;
            float alpha = 0.15f * (1.f - (float)i / 4.f);
            ImU32 glowCol = (col & 0x00FFFFFF) | ((ImU32)(alpha * 255) << 24);
            dl->AddRect(ImVec2(mn.x - expand, mn.y - expand), ImVec2(mx.x + expand, mx.y + expand),
                glowCol, r + expand * 0.5f, 0, 2.f);
        }
    }
}
