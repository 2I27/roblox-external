#pragma once
// Vendored from Phantom-Cheat-Menu-Design (MIT, kyprexs) — rebranded closer.lol, style core kept.
#include "../ImGui/imgui.h"

namespace CloserUI
{
    namespace Colors
    {
        inline ImVec4 BgDark    = ImVec4(0.071f, 0.071f, 0.082f, 1.0f);
        inline ImVec4 BgMedium  = ImVec4(0.102f, 0.102f, 0.122f, 1.0f);
        inline ImVec4 BgLight   = ImVec4(0.145f, 0.145f, 0.157f, 1.0f);
        inline ImVec4 BgPanel   = ImVec4(0.118f, 0.118f, 0.137f, 1.0f);
        inline ImVec4 Accent      = ImVec4(0.780f, 0.490f, 0.730f, 1.0f);
        inline ImVec4 AccentLight = ImVec4(0.831f, 0.647f, 0.788f, 1.0f);
        inline ImVec4 AccentGlow  = ImVec4(0.910f, 0.706f, 0.867f, 1.0f);
        inline ImVec4 AccentDark  = ImVec4(0.545f, 0.353f, 0.498f, 1.0f);
        inline ImVec4 TextPrimary   = ImVec4(0.96f, 0.96f, 0.97f, 1.0f);
        inline ImVec4 TextSecondary = ImVec4(0.82f, 0.82f, 0.85f, 1.0f);
        inline ImVec4 TextMuted     = ImVec4(0.533f, 0.533f, 0.533f, 1.0f);
        inline ImVec4 TextDisabled  = ImVec4(0.400f, 0.400f, 0.400f, 1.0f);
        inline ImVec4 Border       = ImVec4(Accent.x, Accent.y, Accent.z, 0.15f);
        inline ImVec4 BorderHover  = ImVec4(Accent.x, Accent.y, Accent.z, 0.40f);
        inline ImVec4 BorderActive = ImVec4(Accent.x, Accent.y, Accent.z, 0.60f);
    }
    namespace Dim
    {
        inline float WinWidth   = 920.0f;
        inline float WinHeight  = 620.0f;
        inline float Sidebar    = 200.0f;
        inline float Rounding   = 5.0f;
        inline float RoundingSm = 3.0f;
    }
    void InitStyle();
    void SyncAccent(float r, float g, float b);
    void DrawGlow(ImDrawList* dl, ImVec2 mn, ImVec2 mx, ImU32 col, float r = 5.f, float sz = 8.f);
}
