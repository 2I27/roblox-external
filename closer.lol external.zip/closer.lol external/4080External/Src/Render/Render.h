#pragma once
// closer.lol overlay host: transparent window, D3D11, WIC logo.png, game-window follow.
// Menu UI lives in Phantom/ui_menu.* (Phantom-style core, MIT). Style in ui_style.*.
#include <Windows.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <wincodec.h>
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_win32.h"
#include "ImGui/imgui_impl_dx11.h"
#include "Phantom/ui_style.h"
#include "Phantom/ui_menu.h"
#include "../Core/Vars/Vars.h"
#include <vector>
#include <string>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "windowscodecs.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK OverlayWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    if (msg == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

class OverlayWindow {
private:
    HWND windowHandle = nullptr;
    WNDCLASSEXW windowClass{};
    ID3D11Device* d3dDevice = nullptr;
    ID3D11DeviceContext* d3dContext = nullptr;
    IDXGISwapChain* swapChain = nullptr;
    ID3D11RenderTargetView* renderTarget = nullptr;
    ID3D11ShaderResourceView* logoTex = nullptr;
    int logoW = 0, logoH = 0;
    RECT gameRect{0, 0, 0, 0};
    int followTick = 0;

    void LoadLogo() {
        IWICImagingFactory* fac = nullptr;
        if (CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&fac)) != S_OK) return;
        IWICBitmapDecoder* dec = nullptr;
        if (fac->CreateDecoderFromFilename(L"logo.png", nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &dec) != S_OK) { fac->Release(); return; }
        IWICBitmapFrameDecode* frame = nullptr;
        dec->GetFrame(0, &frame);
        IWICFormatConverter* conv = nullptr;
        fac->CreateFormatConverter(&conv);
        conv->Initialize(frame, GUID_WICPixelFormat32bppRGBA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeMedianCut);
        UINT w = 0, h = 0; conv->GetSize(&w, &h);
        std::vector<uint8_t> px((size_t)w * h * 4);
        conv->CopyPixels(nullptr, w * 4, (UINT)px.size(), px.data());
        D3D11_TEXTURE2D_DESC td{};
        td.Width = w; td.Height = h; td.MipLevels = 1; td.ArraySize = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1; td.Usage = D3D11_USAGE_DEFAULT;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sd{ px.data(), w * 4, 0 };
        ID3D11Texture2D* tex = nullptr;
        if (d3dDevice->CreateTexture2D(&td, &sd, &tex) == S_OK) {
            d3dDevice->CreateShaderResourceView(tex, nullptr, &logoTex);
            logoW = (int)w; logoH = (int)h;
            tex->Release();
        }
        conv->Release(); frame->Release(); dec->Release(); fac->Release();
    }

    void SetupD3D11(HWND hwnd) {
        DXGI_SWAP_CHAIN_DESC sd;
        ZeroMemory(&sd, sizeof(sd));
        sd.BufferCount = 2;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hwnd;
        sd.SampleDesc.Count = 1;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
        D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
        D3D_FEATURE_LEVEL obtainedLevel;
        HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            levels, 2, D3D11_SDK_VERSION, &sd, &swapChain, &d3dDevice, &obtainedLevel, &d3dContext);
        if (hr == DXGI_ERROR_UNSUPPORTED) {
            D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0,
                levels, 2, D3D11_SDK_VERSION, &sd, &swapChain, &d3dDevice, &obtainedLevel, &d3dContext);
        }
        ID3D11Texture2D* backBuffer = nullptr;
        swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer));
        if (backBuffer) { d3dDevice->CreateRenderTargetView(backBuffer, nullptr, &renderTarget); backBuffer->Release(); }
    }

    void CleanupD3D11() {
        if (renderTarget) { renderTarget->Release(); renderTarget = nullptr; }
        if (swapChain) { swapChain->Release(); swapChain = nullptr; }
        if (d3dContext) { d3dContext->Release(); d3dContext = nullptr; }
        if (d3dDevice) { d3dDevice->Release(); d3dDevice = nullptr; }
    }

public:
    OverlayWindow() { ZeroMemory(&windowClass, sizeof(windowClass)); }

    static HWND FindGame() {
        HWND h = FindWindowW(NULL, L"Roblox");
        if (!h) h = FindWindowW(NULL, L"RobloxPlayerBeta");
        return h;
    }

    // PID-backed resolve: finds the real game window even when the title isn't "Roblox".
    static BOOL CALLBACK EnumCb(HWND hwnd, LPARAM lp) {
        DWORD wpid = 0;
        GetWindowThreadProcessId(hwnd, &wpid);
        if ((uint32_t)wpid == *(uint32_t*)lp && IsWindowVisible(hwnd)) {
            LONG style = GetWindowLong(hwnd, GWL_STYLE);
            if (style & WS_OVERLAPPEDWINDOW) {
                *(HWND*)(lp + sizeof(uint32_t) * 2) = hwnd;
                return FALSE;
            }
        }
        return TRUE;
    }
    static HWND FindGameByPid(uint32_t pid) {
        if (!pid) return nullptr;
        struct { uint32_t pid; uint32_t pad; HWND out; } ctx{ pid, 0, nullptr };
        EnumWindows(EnumCb, (LPARAM)&ctx);
        return ctx.out ? ctx.out : FindGame();
    }

    // Snap overlay to the game window so ESP/aim align with the client, not the desktop.
    void FollowGameWindow() {
        if (++followTick % 60 != 0) return;
        HWND g = FindGame();
        RECT r{};
        if (g && GetWindowRect(g, &r) && (r.right - r.left) > 200) {
            if (r.left != gameRect.left || r.top != gameRect.top ||
                (r.right - r.left) != (gameRect.right - gameRect.left) ||
                (r.bottom - r.top) != (gameRect.bottom - gameRect.top)) {
                gameRect = r;
                SetWindowPos(windowHandle, HWND_TOPMOST, r.left, r.top,
                    r.right - r.left, r.bottom - r.top, SWP_NOACTIVATE | SWP_SHOWWINDOW);
            }
        }
    }

    bool Initialize() {
        windowClass.cbSize = sizeof(WNDCLASSEXW);
        windowClass.style = CS_HREDRAW | CS_VREDRAW;
        windowClass.lpfnWndProc = OverlayWndProc;
        windowClass.hInstance = GetModuleHandleW(nullptr);
        windowClass.lpszClassName = L"GameOverlay";
        if (!RegisterClassExW(&windowClass)) return false;

        HWND g = FindGame();
        int x = 0, y = 0, w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
        if (g && GetWindowRect(g, &gameRect) && (gameRect.right - gameRect.left) > 200) {
            x = gameRect.left; y = gameRect.top;
            w = gameRect.right - gameRect.left; h = gameRect.bottom - gameRect.top;
        }
        windowHandle = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
            windowClass.lpszClassName, L"GameOverlay",
            WS_POPUP, x, y, w, h, nullptr, nullptr, windowClass.hInstance, nullptr);
        if (!windowHandle) return false;
        // streamproof: exclude overlay from screen capture (Discord/OBS/screenshare)
        if (Vars::Style::streamproof)
            SetWindowDisplayAffinity(windowHandle, WDA_EXCLUDEFROMCAPTURE);
        else
            SetWindowDisplayAffinity(windowHandle, WDA_NONE);
        SetLayeredWindowAttributes(windowHandle, RGB(0, 0, 0), 255, LWA_ALPHA);
        MARGINS margins = { -1, -1, -1, -1 };
        DwmExtendFrameIntoClientArea(windowHandle, &margins);
        ShowWindow(windowHandle, SW_SHOW);
        UpdateWindow(windowHandle);
        SetupD3D11(windowHandle);

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        // bigger, cleaner type: Segoe UI 16px with default fallback
        {
            wchar_t windir[MAX_PATH] = {0};
            GetWindowsDirectoryW(windir, MAX_PATH);
            std::wstring f = std::wstring(windir) + L"\\Fonts\\segoeui.ttf";
            FILE* t = nullptr;
            _wfopen_s(&t, f.c_str(), L"rb");
            if (t) { fclose(t); char mb[MAX_PATH * 2] = {0}; WideCharToMultiByte(CP_UTF8, 0, f.c_str(), -1, mb, sizeof(mb), nullptr, nullptr); io.Fonts->AddFontFromFileTTF(mb, 16.0f); }
        }
        ImGui::StyleColorsDark();
        CloserUI::SyncAccent(Vars::Style::accent[0], Vars::Style::accent[1], Vars::Style::accent[2]);
        CloserUI::InitStyle();
        ImGui_ImplWin32_Init(windowHandle);
        ImGui_ImplDX11_Init(d3dDevice, d3dContext);
        CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
        LoadLogo();
        CloserUI::g_State.logoTex = (void*)logoTex;
        CloserUI::g_State.logoW = logoW;
        CloserUI::g_State.logoH = logoH;
        return true;
    }

    void BeginFrame() {
        MSG msg;
        while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessage(&msg); }
        FollowGameWindow();
        static int lastSP = -1;
        if ((int)Vars::Style::streamproof != lastSP) {
            lastSP = (int)Vars::Style::streamproof;
            SetWindowDisplayAffinity(windowHandle, Vars::Style::streamproof ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE);
        }
        CloserUI::SyncAccent(Vars::Style::accent[0], Vars::Style::accent[1], Vars::Style::accent[2]);
        if (Vars::menuOpen)
            SetWindowLong(windowHandle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
        else
            SetWindowLong(windowHandle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
    }

    void RenderMenu() {
        CloserUI::g_State.open = Vars::menuOpen;
        CloserUI::RenderMenu();
        Vars::menuOpen = CloserUI::g_State.open;
    }

    void EndFrame() {
        ImGui::Render();
        float clearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
        d3dContext->OMSetRenderTargets(1, &renderTarget, nullptr);
        d3dContext->ClearRenderTargetView(renderTarget, clearColor);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        swapChain->Present(1, 0);
    }

    void Cleanup() {
        if (logoTex) { logoTex->Release(); logoTex = nullptr; }
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        CleanupD3D11();
        if (windowHandle) { DestroyWindow(windowHandle); windowHandle = nullptr; }
        UnregisterClassW(windowClass.lpszClassName, windowClass.hInstance);
    }

    HWND GetWindowHandle() const { return windowHandle; }
    RECT GameRect() const { return gameRect; }
};
