@echo off
REM language: batch, file: 4080External/build.bat — builds x64 Release exe, no VS IDE needed
REM Requires: Visual Studio Build Tools (MSVC v143+) — winget install Microsoft.VisualStudio.2022.BuildTools
setlocal
where msbuild >nul 2>nul
if %errorlevel% neq 0 (
  echo [!] msbuild not found. Trying vswhere...
  for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe 2^>nul`) do set MSBUILD=%%i
  if not defined MSBUILD if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe" set "MSBUILD=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
  if not defined MSBUILD if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe" set "MSBUILD=%ProgramFiles%\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"
) else ( set MSBUILD=msbuild )
if not defined MSBUILD ( echo [!] Install Build Tools first. & pause & exit /b 1 )
"%MSBUILD%" 4080External.vcxproj /p:Configuration=Release /p:Platform=x64 /m
if %errorlevel% equ 0 ( echo [+] Built: x64\Release\closer.exe — runs as closer.lol ) else ( echo [!] Build failed. )
pause
