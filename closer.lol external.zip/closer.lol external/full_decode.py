K = {'8':50,'t':49,'1':48,'2':39,'K':44,'f':59,'d':2,'J':33,'6':57,'s':12,'q':34,'0':36,'A':1,'l':24,'3':3,'B':28,'g':7,'n':16,'5':26,'c':40,'j':13,'E':9,'m':5,'v':58,'F':21,'k':42,'x':61,'T':10,'i':55,'L':29,'Q':0,'z':60,'N':4,'e':43,'I':41,'C':37,'O':45,'Y':25,'a':47,'+':17,'b':46,'Z':53,'H':8,'y':18,'R':51,'w':54,'9':14,'D':62,'4':15,'p':32,'h':19,'X':6,'/':35,'u':20,'7':63,'W':27,'M':38,'o':22,'r':11,'V':30,'S':52,'G':56,'P':23,'U':31}
H = {'/':23,'o':8,'p':3,'E':59,':':84,'s':58,'B':62,'1':46,'U':48,'3':47,'O':19,'Z':11,'h':64,'i':26,'$':70,'G':31,'6':20,'f':61,'b':12,'>':22,'e':77,'u':0,'X':42,'(':73,'<':17,'r':37,'2':21,'A':80,'a':29,'Q':16,'[':53,',':63,'^':32,'V':57,'&':65,'-':56,'t':52,'"':27,'`':28,'%':79,'q':78,';':75,'J':71,'S':1,'g':25,'8':82,'.':49,'C':76,'j':38,'H':30,'!':60,'L':41,'I':50,'@':4,'4':7,'_':13,']':5,'P':74,'k':6,'*':68,'+':40,'l':55,'M':15,"'":10,'0':83,'T':34,'d':39,'=':66,')':54,'F':44,'5':81,'m':43,'7':35,'n':24,'?':51,'Y':2,'D':18,'\\':69,'c':45,'R':33,'K':67,'9':9,'N':14,'#':72,'W':36}

def b64(s):
    out=bytearray(); D=0; G=0; i=0
    while i<len(s):
        ch=s[i]
        if ch=="=":
            pad=len(s)-i
            if G==2 and pad>=2: out.append((D//65536)%256)
            elif G==3 and pad>=1: out.append((D//65536)%256); out.append(((D%65536)//256)%256)
            break
        v=K.get(ch)
        if v is None: break
        D+=v*(64**(3-G)); G+=1
        if G==4: G=0; out.append((D//65536)%256); out.append(((D%65536)//256)%256); out.append(D%256); D=0
        i+=1
    return bytes(out)

def b85(s):
    out=bytearray(); Hh=0; y=len(s)
    while Hh<y:
        d=y-Hh; q=5 if d>=5 else d
        J=0; B=q>1; ok=True
        for dd in range(5):
            if dd<q:
                v=H.get(s[Hh+dd])
                if v is None: ok=False; B=False; break
                J=J*85+v
            else: J=J*85+84
        if B and ok:
            b0=(J//16777216)%256; b1=(J//65536)%256; b2=(J//256)%256; b3=J%256
            if q==5: out.extend([b0,b1,b2,b3])
            elif q==4: out.extend([b0,b1,b2])
            elif q==3: out.extend([b0,b1])
            elif q==2: out.extend([b0])
        Hh+=q
    return bytes(out)

# Raw d entries in source order (Lua escapes already resolved)
d=[
",PZxOYP+JLXmqWXu=",
"piZFOI`:XJWTLsJ\\",
",BMFOWiYC",
",sPQ8+CjNsot/5ZErLQ==",
",sgBZVXtjFSCes1==",
"pr9ojg7L]",
"prTR2'",
"pO5?Ou55",
",ajVcFp==",
"pT#\",Cr9ojg7L]",
",F3JI+CC6hNN1y/EYo0n=",
",se8/dxs=",
",YijZlp==",
",0ReL1p==",
"pRO6l$",
",BXjJWX1=",
",jXEA+/jsYM+R9NmJ",
"pD^m",
"p7rEEJ^Ip]",
"pW]k_;rf!Rp>%M^7",
"pO!,>C(B?mPZ;&dUJ&';QO=5_;j#fJIqo#Yt)ROWH",
",Lo61loje",
",YwZJLXjc",
"pHl+[E7H",
",PZxIWM+CVQ==",
"pG5d2%G\"i",
",lwJJBp==",
"pROVM0^I:-",
",y/+eW/Eyhmjo5XtbL20=",
"p^(mc\"W=-<URUV\"CQ\\1",
",BPFCLoFUWw6ULXFKYPAaB2n=",
",l2CSYn==",
",8wBZVA0MkawLEnA+nTRhX52jA9gx1VFqqTzcc9yUXJSqF0EJgp==",
",Jt4WvPVXquiM231+Ncijm0K7sG+E+oFZCOM2JBwfzIYcdxKBAnmMxvgHvTwWxRXg9EmqrXXnt98kYoC6JMa8u9D8Keb4PWAcEjlv0UO58/Q3pqY43iS1T7d5hvBt2aF+KRIU8LP4oRFWsclsxjNAsY+KJJ1W2re+fNF5DuT8MF/Qtq02tJ15e/GfIs4sZmtf+DQGl2uDUfuA6zQXNcnuIy1tGPGis5Gu6cIgHLKkihFlgiTCcyL5lZXuYl80Cvwh9qi1sVwiXmcVQeX62VfqD04Wf0/Ak6WiGC/FCuM8cVKfXQ1Qnt1WcRtKwkJ89f/y2sTMgyVmB4CVQlFAi14zyBzP3mhmSqtFLMo65VsV5Sb1DT6z0MFIsR+dgilvUL7eOf5lQEK35qbpXsrUpfKNfjPzpXoYWOI53kmcVh7RNwE4VptUtyhccAqmdjG=",
"pWh,#57\\Y",
"pR2.#^/(c",
"pDs=g&_1KT",
",yg+SBNLCLQ==",
",d+em8A5B6NfZZrApTC1Pif4bmLLGHiuy+205KflKnaE/qZBsiqtkBhzIuHeFXKfRgqLYv2qw3d5988UBbV0s5YkwgJElG95CZZx8euXSpM5zLA0Y2FqfSyM7wHtRkN6oxqSK1mIQ1y3RdrAyRTyMvV4Hq4ofIgU2",
"phb^'",
",A2exnSeeCsjcsbCR",
",9p==",
",LXxbLoZqYPH=",
"p>8HB]M#?0hiLI./",
"pjVE;Cj@j7j^<]`Q2D",
",52E2noIuLNE9BCH8ygc=",
",LXxRLgEIWMB=",
";",
"prWMqbRQsZ&RmH#nGN",
",MZlOudoZsn==",
",W3N=",
",uNz1LRCGL1==",
",FXmOBXF8HN+CLXF/LXF0Hn==",
",LXmqWXu=",
"p6:n%h/O>BJTL_!F",
"pr4XdQ^?[G]Ggr@h",
",uhEv+0OJY0l8ygj+F3l=",
",9NIkl2YAVPAmYZ+Khp==",
",W3H=",
",PZx2l1==",
",YPE8WiH=",
"p^qoT4W)",
"p7__1S",
]
assert len(d)==63, len(d)
# shuffle: reverse [1,63],[1,42],[43,63] (1-indexed)
def rev(a,b):
    a-=1; b-=1
    while a<b: d[a],d[b]=d[b],d[a]; a+=1; b-=1
rev(1,63); rev(1,42); rev(43,63)

for i,w in enumerate(d,1):
    if w.startswith(","): raw=b64(w[1:])
    elif w.startswith("p"): raw=b85(w[1:])
    else:
        with open("C:\\Users\\seams\\AppData\\Local\\Temp\\opencode\\decoded.txt","a",encoding="utf-8") as f: f.write(f"{i:3d}: {w!r}  [raw]\n")
        continue
    try: txt=raw.decode()
    except: txt="BYTES:"+raw.hex()
    with open("C:\\Users\\seams\\AppData\\Local\\Temp\\opencode\\decoded.txt","a",encoding="utf-8") as f: f.write(f"{i:3d}: {txt!r}\n")
